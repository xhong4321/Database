#ifndef RECORD_H
#define RECORD_H

#include <iostream>
#include <iostream>
#include <fstream>
using namespace std;

//utility functions
bool file_exists(const char filename[]);

void open_fileRW(fstream& f, const char filename[]) throw(char*);
void open_fileW(fstream& f, const char filename[]);

class Record{
public:
    //when you construct a Record, it's either empty or it
    //  contains a word
    Record(){
        _record[0] = NULL;
        recno = -1;
    }

    Record(char str[]){
        strncpy(_record, str, MAX);
    }
    Record(string s){
        strncpy(_record, s.c_str(), MAX);
    }
    long write(fstream& outs);              //returns the record number
    long read(fstream& ins, long recno);    //returns the number of bytes
                                            //      read = MAX, or zero if
                                            //      read passed the end of file


    friend ostream& operator<<(ostream& outs,
                               const Record& r);
private:
    static const int MAX = 10;
    int recno;
    char _record[MAX+1];
};



#endif // RECORD_H
