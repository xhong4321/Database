#ifndef Z_OUTPUT_1D_RECORD_H
#define Z_OUTPUT_1D_RECORD_H

/*
 *
 *
 *
 *
 *
 *
 * ALL RESULTS HAVE BEEN VERIFIED
 *
 *

================================
zero
one
two
three
four
five
six
seven
eight
nine
[zero] was written into file as record: 0
[one] was written into file as record: 1
[two] was written into file as record: 2
[three] was written into file as record: 3
[four] was written into file as record: 4
[five] was written into file as record: 5
[six] was written into file as record: 6
[seven] was written into file as record: 7
[eight] was written into file as record: 8
[nine] was written into file as record: 9
record 3: three
record 6: six
number of bytes read: 0



================================
Press <RETURN> to close this window...
 *
 *
 *
 *
 *
 */

#endif // Z_OUTPUT_1D_RECORD_H
