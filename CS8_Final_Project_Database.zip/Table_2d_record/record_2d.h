#ifndef RECORD_2D_H
#define RECORD_2D_H


#include <iostream>
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

////utility functions
//bool file_exists(const char filename[]);

//void open_fileRW(fstream& f, const char filename[]) throw(char*);
//void open_fileW(fstream& f, const char filename[]);

class Record_2d {
public:
    //when you construct a Record, it's either empty or it
    //  contains a word
    Record_2d(){
        for ( int i = 0 ; i<MAX_ROWS ; i++ ) {
            _record[i][0] = NULL;
        }
        recno = -1;
        _num_of_fields = 0;
    }

//    Record_2d ( char record[20][50] ){
//        for ( int i = 0 ; i < MAX_ROWS ; i++ ) {
//            _record[i][0] = NULL;
//        }
//        for ( int i = 0 ; i < MAX_ROWS ; i++ ) {
//            strcpy(_record[i], record[i].c_str());
//        }
//        _num_of_fields = strlen(record);
//    }

    Record_2d( vector<string> vs){
        for ( int i = 0 ; i<MAX_ROWS ; i++ ) {
            _record[i][0] = NULL;
        }
        for ( int i = 0 ; i < vs.size() ; i++ ) {
            strcpy(_record[i], vs[i].c_str());
        }
        _num_of_fields = vs.size();
    }

    vector<string> get_record(){
        const bool debug = true;
        vector<string> v;
       // if (debug) cout << "get_record(): " << _num_of_fields <<endl;
        for ( int i = 0 ; i < MAX_ROWS ; i++ ) {
            v.push_back(string(_record[i]));
        }
        return v;
    }

    long write(fstream& outs);              //returns the record number
    long read(fstream& ins, long recno);    //returns the number of bytes
                                            //      read = MAX, or zero if
                                            //      read passed the end of file


    friend ostream& operator<<(ostream& outs,
                               const Record_2d& r);
private:
    static const int MAX_ROWS = 20;
    static const int MAX_COLS = 50;
    int recno;
    int _num_of_fields;
    char _record[MAX_ROWS][MAX_COLS];
};

template<typename T>
ostream& operator<<(ostream& outs, const vector<T>& v)
{

    for ( int i = 0 ; i<v.size() ; i++ ) {
        if ( v[i] != T() ){
            outs << setw(15) << v[i];
        }
        else {
            break;
        }
    }
    return outs;
}


#endif // RECORD_2D_H
