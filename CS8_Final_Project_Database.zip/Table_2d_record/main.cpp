#include <iostream>
#include "record.h"
#include "record_2d.h"
#include <vector>
using namespace std;



void test_1d_record();
void test_2d_record();

int main()
{

    cout <<endl<<endl<<endl<< "================================" << endl;

    //test_1d_record(); //GOOD
    test_2d_record(); //GOOD

    cout <<endl<<endl<<endl<< "================================" << endl;

    return 0;
}

void test_1d_record()
{
    string list[10] = {"zero",
                       "one",
                       "two",
                       "three",
                       "four",
                       "five",
                       "six",
                       "seven",
                       "eight",
                       "nine"};

    for (int i = 0; i< 10; i++){
        cout<<list[i]<<endl;
    }

    fstream f;
    //reset the file:
    open_fileW(f, "record_list.bin"); //open a file to write
    for (int i= 0; i<10; i++){
        Record r(list[i]);      //filling the envelop
        long recno = r.write(f); //return a record number
        cout<<"["<<list[i] <<"]"<< " was written into file as record: "<<recno<<endl;
    }
    f.close();



    Record r;
    //open the file for reading and writing.
    open_fileRW(f, "record_list.bin" ); //read and write
    r.read(f, 3);       //empty envelop to be filled by the Record object
    cout<<"record 3: "<<r<<endl;    //insertion operator of the Record object
    r.read(f, 6);
    cout<<"record 6: "<<r<<endl;

    //reading passed the end of file:
    long bytes = r.read(f, 19);
    cout<<"number of bytes read: "<<bytes<<endl;
}

void test_2d_record()
{
    vector<string> records[4] = {
        {"Bob","Jones","CS"},
        {"Jane","Doe","Math"},
        {"Steve","Booker","CS"},
        {"Jack","Thomas","Phys"},
    };

    fstream f;
    open_fileW(f, "two_d_record_list.bin");
    for ( int i = 0 ; i < 4 ; i++ ) {
        Record_2d rec(records[i]);
        int record_num = rec.write(f);
        cout << "wrote record " << record_num << endl;
    }
    f.close();

    cout << endl<<endl<<endl<<"======================================" <<endl;

    Record_2d r;
    open_fileRW(f,"two_d_record_list.bin");
    int recno = 0;
    r.read(f,recno); //read the first record
    while ( !f.eof() ) {
        cout << "["<<recno<<"]" << r.get_record() << endl;
        recno++;

        r.read(f,recno);
    }

}



