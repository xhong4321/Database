#ifndef Z_OUTPUT_2D_RECORD_H
#define Z_OUTPUT_2D_RECORD_H

/*
 *
 *
 *
 *
 *
 *
 *
 * ALL RESULTS HAVE BEEN VERIFIED
 *
 *
 *


================================
wrote record 0
wrote record 1
wrote record 2
wrote record 3



======================================
[0]get_record(): 0
Bob Jones CS
[1]get_record(): 0
Jane Doe Math
[2]get_record(): 0
Steve Booker CS
[3]get_record(): 0
Jack Thomas Phys



================================
Press <RETURN> to close this window...
 *
 *
 *
 *
 *
 */

#endif // Z_OUTPUT_2D_RECORD_H
