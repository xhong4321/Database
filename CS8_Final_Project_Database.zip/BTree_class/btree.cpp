#include "btree.h"

void test_is_valid()
{
    cout << "Manually Test is_valid: " << endl;
    BTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(100);
    bt.insert(34);
    cout << bt << endl;
    if ( !bt.is_valid() ){
        cout << "The BTree is invalid." << endl;
    }
    else {
        cout << "The BTree is valid." << endl;
    }
    cout << endl << endl;
    cout << "============================================" << endl;
    cout << "Randomly Test is_valid: " << endl;
    cout << "-----------------------------------" << endl;
    cout << "Check 1000 inserts:" << endl;
    bt.clear_tree();
    for ( int i = 0 ; i < 1000 ; i++ ) {
        int entry = rand()%2000 + 1;
        cout << "The Random Number" << entry << endl;
        bt.insert(entry);
    }
    cout << bt << endl;
    if ( !bt.is_valid() ){
        cout << "The BTree is invalid." << endl;
    }
    else {
        cout << "YES!!The BTree is valid." << endl;
        cout << "1000 elements have been inserted successfully!" << endl;
    }
    cout << endl << endl;
    cout << "-----------------------------------" << endl;
    cout << "Check 1000000 inserts:" << endl;
    int n = 1000000;
    int range = 20000000;
    bt.clear_tree();
    for ( int i = 0 ; i < n ; i++ ) {
        int entry = rand()%range + 1;
        //cout << "The Random Number" << entry << endl;
        bt.insert(entry);
    }
    cout << bt << endl;
    if ( !bt.is_valid() ){
        cout << "The BTree is invalid." << endl;
    }
    else {
        cout << "YES!!!The BTree is valid." << endl;
        cout << n << " elements have been inserted successfully!" << endl;
    }
}

void test_insert()
{
    cout << "=================================================" << endl;
    cout << "Test Insert:" << endl << endl;
    BTree<string> bt;
    bt.insert("Jerry");
    bt.insert("Tony");
    bt.insert("Kevin");
    bt.insert("Link");
    bt.insert("Tommy");
    bt.insert("Nathan");
    bt.insert("Yubo");
    bt.insert("Stephine");
    bt.insert("Xiangyu");
    bt.insert("Hong");
    bt.insert("Zack");
    cout << bt << endl;
    cout << "Delete Jerry:" << endl;
    bt.remove("Jerry");
    cout << bt << endl << endl;  //so far so good
    cout << "Delete Tony:" << endl;
    bt.remove("Tony");
    cout << bt << endl << endl;
    cout << "Delete Hong:" << endl;
    bt.remove("Hong");
    cout << bt << endl << endl;
    cout << "Delete Wang:" << endl;
    bt.remove("Wang");
    cout << bt << endl << endl;
    cout << "Delete Jessica:" << endl;
    bt.remove("Jessica");
    cout << bt << endl << endl;
    cout << "Delete Nathan:" << endl;
    bt.remove("Nathan");
    cout << bt << endl << endl;
    cout << "Delete Link:" << endl;
    bt.remove("Link");
    cout << bt << endl << endl;
}

void test_get_and_contains()
{
    cout << "=================================================" << endl;
    cout << "Test Get and Contain:" << endl << endl;
    BTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    cout << bt << endl;

    if ( bt.contains(7) ){
        cout << "Yes, contains 7" << endl;
    }
    else {
        cout << "No, doesn't contain 7" << endl;
    }
    if ( bt.contains(10) ){
        cout << "Yes, contains 10" << endl;
    }
    else {
        cout << "No, doesn't contain 10" << endl;
    }
    if ( bt.contains(3) ){
        cout << "Yes, contains 3" << endl;
    }
    else {
        cout << "No, doesn't contain 3" << endl;
    }
    if ( bt.contains(100) ){
        cout << "Yes, contains 100" << endl;
    }
    else {
        cout << "No, doesn't contain 100" << endl;
    }
    if ( bt.contains(89) ){
        cout << "Yes, contains 89" << endl;
    }
    else {
        cout << "No, doesn't contain 89" << endl;
    }

    cout << "We should alwasy get the item because we insert the item if we "
            "find out that the btree doesn't have that item." << endl;
    int item1 = bt.get(5);
    if ( item1 == 5 ){
        cout << "Yes, we get 5!" << endl;
    }
    else {
        cout << "No, we didn't get 5." << endl;
    }

    int item2 = bt.get(6);
    if ( item2 == 6 ){
        cout << "Yes, we get 6!" << endl;
    }
    else {
        cout << "No, we didn't get 6." << endl;
    }

    int item3 = bt.get(100);
    if ( item3 == 100 ){
        cout << "Yes, we get 100!" << endl;
    }
    else {
        cout << "No, we didn't get 100." << endl;
    }

    int item4 = bt.get(34);
    if ( item4 == 34 ){
        cout << "Yes, we get 34!" << endl;
    }
    else {
        cout << "No, we didn't get 34." << endl;
    }
    cout << "Result: " << endl;
    cout << bt << endl;
}

void test_copy_and_clear()
{
    cout << "=================================================" << endl;
    cout << "Test Copy and CLear:" << endl << endl;
    BTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(100);
    bt.insert(34);
    cout << bt << endl;
    cout << "Test Copy:" << endl;
    BTree<int> bt2;
    bt2.copy_tree(bt);
    cout << bt2 << endl;
    cout << "Test Clear:" << endl;
    bt2.clear_tree();
    cout << bt2 << endl;
}

void test_big_three()
{
    cout << "=================================================" << endl;
    cout << "Test Big Three:" << endl << endl;
    BTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(100);
    bt.insert(34);
    cout << bt << endl;
    cout << "Test Copy Constructor:" << endl;
    BTree<int> bt2(bt);
    cout << bt2 << endl;
    cout << "Test Assignment operator:" << endl;
    BTree<int> bt3;
    bt3 = bt2;
    cout << bt3 << endl;
}

void test_remove()
{
    cout << "=================================================" << endl;
    cout << "Test Remove:" << endl << endl;
    BTree<int> bt;
    bt.insert(40);
    bt.insert(49);
    bt.insert(24);
    bt.insert(37);
    bt.insert(32);
    bt.insert(23);
    bt.insert(26);
    bt.insert(38);
    bt.insert(7);
    bt.insert(50);
    bt.insert(48);
    bt.insert(6);
    bt.insert(45);
    bt.insert(29);
    bt.insert(8);
    bt.insert(6);//
    bt.insert(4);
    bt.insert(32);//
    bt.insert(1);
    bt.insert(13);
    bt.insert(37);//
    bt.insert(32);//
    bt.insert(30);
    bt.insert(18);
    bt.insert(28);
    bt.insert(29);//
    bt.insert(28);//
    bt.insert(35);
    bt.insert(42);
    bt.insert(25);
    cout << bt << endl;
    cout << "Delete 6:" << endl;
    bt.remove(6);
    cout << bt << endl << endl;  //so far so good
    cout << "Delete 11:" << endl;
    bt.remove(11);
    cout << bt << endl << endl;
    cout << "Delete 28:" << endl;
    bt.remove(28);
    cout << bt << endl << endl;
    cout << "Delete 21:" << endl;
    bt.remove(21);
    cout << bt << endl << endl;
    cout << "Delete 9:" << endl;
    bt.remove(9);
    cout << bt << endl << endl;
    cout << "Delete 24:" << endl;
    bt.remove(24);
    cout << bt << endl << endl;
    cout << "Delete 6:" << endl;
    bt.remove(6);
    cout << bt << endl << endl;
    cout << "Delete 13:" << endl;
    bt.remove(13);
    cout << bt << endl << endl;
    cout << "Delete 12:" << endl;
    bt.remove(12);
    cout << bt << endl << endl;  //so far so good
    cout << "Delete 46:" << endl;
    bt.remove(46);
    cout << bt << endl << endl;
    cout << "Delete 32:" << endl;
    bt.remove(32);
    cout << bt << endl << endl;
    cout << "Delete 44:" << endl;
    bt.remove(44);
    cout << bt << endl << endl;
    cout << "Delete 14:" << endl;
    bt.remove(14);
    cout << bt << endl << endl;
    cout << "Delete 28:" << endl;
    bt.remove(28);
    cout << bt << endl << endl;
    cout << "Delete 39:" << endl;
    bt.remove(39);
    cout << bt << endl << endl;
    cout << "Delete 8:" << endl;
    bt.remove(8);
    cout << bt << endl << endl;
    cout << "Delete 2:" << endl;
    bt.remove(2);
    cout << bt << endl << endl;
    cout << "Delete 2:" << endl;
    bt.remove(2);
    cout << bt << endl << endl;
    cout << "Delete 21:" << endl;
    bt.remove(21);
    cout << bt << endl << endl;
    cout << "Delete 32:" << endl;
    bt.remove(32);
    cout << bt << endl << endl;
    cout << "Delete 40:" << endl;
    bt.remove(40);
    cout << bt << endl << endl;
    cout << "Delete 42:" << endl;
    bt.remove(42);
    cout << bt << endl << endl;
    cout << "Delete 45:" << endl;
    bt.remove(45);
    cout << bt << endl << endl;
    cout << "Delete 26:" << endl;
    bt.remove(26);
    cout << bt << endl << endl;
    if ( !bt.is_valid() ){
        cout << "The BTree is invalid." << endl;
        // cout << bt << endl;
       }
       else {
        cout << "YES!!!The BTree is valid." << endl;
    }
}

void test_remove_crazyMode() //GOOD!!
{
    BTree<int> bt;
//    int n = 100;
    for ( int i = 0 ; i < 100000 ; i++ ) {
        int item = rand()%500000 + 1;
        cout << i << " time : insert " << item << endl;
        bt.insert(item);
//        if ( !bt.is_valid() ){
//            cout << "The BTree is invalid." << endl;
//            break;
//        }
//        else {
//            cout << "YES!!!The BTree is valid." << endl;
//            cout << i << " elements have been inserted successfully!" << endl;
//        }
    }
    cout << bt << endl;
    for ( int j = 0 ; j < 80000 ; j++ ) {
        int item = rand()%200000 + 1;
        cout << j << " time : remove " << item << endl;
        bt.remove(item);
//        if ( !bt.is_valid() ){
//            cout << "The BTree is invalid." << endl;
//           // cout << bt << endl;
//            break;
//        }
//        else {
//            cout << "YES!!!The BTree is valid." << endl;
//            cout << j << " elements have been removed successfully!" << endl;
//        }
       // cout << bt << endl;
    }
    if ( !bt.is_valid() ){
        cout << "The BTree is invalid." << endl;
        // cout << bt << endl;
       }
       else {
        cout << "YES!!!The BTree is valid." << endl;
    }
   // cout << bt << endl;
}

void test_remove_to_zero()
{
    BTree<int> bt;
    bt.insert(99);
    bt.insert(71);
    bt.insert(56);
    cout << bt << endl;
    bt.remove(56);
    cout << bt << endl;
    bt.remove(71);
    cout << bt << endl;
    bt.remove(99);
    cout << bt << endl;
}

                       //1000           //100
void test_BTree_auto(int tree_size, int how_many, bool report){
    bool verified = true;
    for (int i = 0; i< how_many; i++){

        if (report){
            cout<<"*********************************************************"<<endl;
            cout<<" T E S T:    "<<i<<endl;
            cout<<"*********************************************************"<<endl;
        }

        if (!test_BTree_auto(tree_size, report)){
            cout<<"T E S T :   ["<<i<<"]    F A I L E D ! ! !"<<endl;
            verified = false;
            return;
        }

    }
    cout<<"**************************************************************************"<<endl;
    cout<<"**************************************************************************"<<endl;
    cout<<"             E N D     T E S T: "<<how_many<<" tests of "<<tree_size<<" items: ";
    cout<<(verified?"VERIFIED": "VERIFICATION FAILED")<<endl;
    cout<<"**************************************************************************"<<endl;
    cout<<"**************************************************************************"<<endl;

}
                          //1000
bool test_BTree_auto(int how_many, bool report){
    const int MAX = 10000;
    assert(how_many < MAX);
    BTree<int> bt;
    int a[MAX];
    int original[MAX];
    int deleted_list[MAX];

    int original_size;
    int size;
    int deleted_size = 0;

    //fill a[ ] (0,1,2,3,4,5,6,...,999)
    for (int i= 0; i< how_many; i++){
        a[i] = i;
    }
    //shuffle a[ ]: Put this in a function!
    for (int i = 0; i< how_many; i++){
        int from = Random(0, how_many-1); //a random number 0-999
        int to = Random(0, how_many -1); //a random number 0-999
        int temp = a[to];
        a[to] = a[from];
        a [from] = temp;
    }
    //copy  a[ ] -> original[ ]:
    copy_array(original, a, how_many, how_many);
    size = how_many;
    original_size = how_many;
    for (int i=0; i<size; i++){
        bt.insert(a[i]);
    }

    if (report){
        cout<<"========================================================"<<endl;
        cout<<"  "<<endl;
        cout<<"========================================================"<<endl;
        cout<<bt<<endl<<endl;
    }
    for (int i= 0; i<how_many; i++){
        int r = Random(0, how_many - i - 1);
      //  cout << r <<endl;
      //  cout << i << " times !!!!!!!!" <<endl;
        if (report){
            cout<<"========================================================"<<endl;
            cout<<bt<<endl;
            cout<<". . . . . . . . . . . . . . . . . . . . . . . . . . . . "<<endl;
            cout<<"deleted: "; print_array(deleted_list, deleted_size);
            cout<<"   from: "; print_array(original, original_size);
            cout<<endl;
            cout<<"  REMOVING ["<<a[r]<<"]"<<endl;
            cout<<"========================================================"<<endl;
        }
        bt.remove(a[r]);

     //   cout << 111111111 << endl;

        delete_item(a, r, size, deleted_list[deleted_size++]);
     //   cout << 222 << endl;
        if (!bt.is_valid()){
            cout<<setw(6)<<i<<" I N V A L I D   T R E E"<<endl;
            cout<<"Original Array: "; print_array(original, original_size);
            cout<<"Deleted Items : "; print_array(deleted_list, deleted_size);
            cout<<endl<<endl<<bt<<endl<<endl;
            return false;
        }
    }
    if (report) cout<<" V A L I D    T R E E"<<endl;

    return true;
}

int Random(int lo, int hi)
{
    int r = rand()%(hi-lo+1)+lo;

    return r;
}

void test_count_size()
{
    cout << "============================================" << endl;
    cout << "Test Size: " << endl;
    BTree<int> bt;
    BTree<int> bt1;
    bt1.insert(5);
    bt1.insert(4);
    bt1.insert(3);
    bt1.insert(2);
    bt1.insert(6);
    bt1.insert(7);
    bt1.insert(8);
    bt1.insert(1);
    bt1.insert(89);
    bt1.insert(17);
    bt1.insert(5);
    bt1.insert(100);
    bt1.insert(34);
    cout << bt1 << endl;
    cout << "BTree's size is: " << bt1.size() << endl << endl;
    cout << "Let's test another BTree: " << endl;
    bt.insert(40);
    bt.insert(49);
    bt.insert(24);
    bt.insert(37);
    bt.insert(32);
    bt.insert(23);
    bt.insert(26);
    bt.insert(38);
    bt.insert(7);
    bt.insert(50);
    bt.insert(48);
    bt.insert(6);
    bt.insert(45);
    bt.insert(29);
    bt.insert(8);
    bt.insert(6);//
    bt.insert(4);
    bt.insert(32);//
    bt.insert(1);
    bt.insert(13);
    bt.insert(37);//
    bt.insert(32);//
    bt.insert(30);
    bt.insert(18);
    bt.insert(28);
    bt.insert(29);//
    bt.insert(28);//
    bt.insert(35);
    bt.insert(42);
    bt.insert(25);
    cout << bt << endl;
    cout << "BTree's size is: " << bt.size() << endl;
}



