#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H

/*
Features:

    -Not Implemented: None.

    -Implemented: This program can manpluate insert, copy and clear, big three,
    find, contain, get, get existing, extraction operator, calculate the size
    of BTree, and remove. I tested my BTree's insertion and deletion using the
    method that Professor posted on canvas page. In addition, I also tested
    it manually and randomly, and they all worked very well because they all
    passed is_valid function.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
    After finishing this program, I had a better idea of what a BTree is, and
    I understand BTree better, especially the structure of BTree. Right now,
    my BTree is pretty good, and I don't think there is any more bug in my
    BTree since I tested my BTree with 100000 times insertion and 80000 times
    deletion in my own testing function, and my BTree also passed Professor's
    testing functions. It's very hard to debug this program, but I enjoyed the
    progress because I felt better and better and understood better and better
    every time I went into checking each single function. I have a lot of
    comments in my project because I used them to check my functions. I think
    I will delete those later because map and multi map is based on BTree, so
    I think it's better to keep those comments there just in case. I think the
    most important part of this program is to understand the structure of BTree
    and know how to switch between array and BTree object. Ths project is hard
    but it's clear for me.
*/

#endif // Z_WORK_REPORT_H
