/*
 * Author: Xiangyu Hong
 * Project: BT BTree class
 * Purpose: The purpose of this program is to create a BTree class and test the
 * BTree functions' every single function; then, I will use the auto test
 * method on the canvas to test my BTree. In addition, we use is_valid to test
 * BTree.
 * Notes: I only used integer to test the pogram
*/

#include <iostream>
#include "btree.h"
//#include "btree_array.h" //This is for testing my array fnctions
using namespace std;

void test_ordered_insert();
void test_merge();
void test_insert_array();
void test_shift();
void test_copy();
void test_split();
void test_first_ge();
void test_detach();
void test_ascending();
void test_is_gt();
void test_is_le();

int main()
{
    srand(time(0));
    cout << endl << endl << endl;

    cout << "what's up bro!" << endl;

    //test_insert(); //GOOD
    //test_get_and_contains(); //GOOD
    //test_is_valid(); //GOOD
    //test_copy_and_clear(); //GOOD
    //test_big_three(); //GOOD
    //test_remove(); //GOOD
    //test_remove_crazyMode(); //GOOD
    //test_remove_to_zero(); //GOOD
    //test_count_size(); //GOOD
    test_BTree_auto(1000,100,false); //GOOD


//    test_shift(); //GOOD
//    test_insert_array(); //GOOD
//    test_ordered_insert(); //GOOD
//    test_merge(); //GOOD
//    test_copy(); //GOOD
//    test_split(); //GOOD
//    test_first_ge(); //GOOD
//    test_detach(); //GOOD
//    test_ascending(); //GOOD
//    test_is_gt(); //GOOD
//    test_is_le(); //GOOD


    cout  << "congrats!" << endl;

    cout << endl << endl << "================End===============" << endl;
    return 0;
}

void test_shift()
{
    cout << "======================================================" << endl;
    cout << "               Test Shift Functions:" << endl;
    cout << "======================================================" << endl;
    cout << "shift right: " << endl;
    int a1[] = {1,2,3,4,5};
    int n = 5;
    print_array(a1,n,0);
    shift_right(a1,1,n);
    cout << "new size: " << n << endl;
    print_array(a1,n,0);

    cout << "shift left: " << endl;
    int b1[] = {1,2,3,4,5};
    int t = 5;
    print_array(b1,t,0);
    shift_left(b1,2,t);
    cout << " new size: " << t << endl;
    print_array(b1,t,0);
}

void test_insert_array()
{
    cout << "======================================================" << endl;
    cout << "                Test Insert Array:" << endl;
    cout << "======================================================" << endl;
    int n2 = 4;
    int a1[] = {10,20,30,40};
    cout << "Insert 3 into the follwing array at index of 2:" << endl;
    print_array(a1,n2,0);
    insert_item(a1,2,n2,3);
    print_array(a1,n2,0);
}

void test_ordered_insert()
{
    cout << "======================================================" << endl;
    cout << "             Test Ordered Insert Array:" << endl;
    cout << "======================================================" << endl;
    int n2 = 4;
    int a1[] = {10,20,30,40};
    cout << "Ordered insert 100 into the follwing array:" << endl;
    print_array(a1,n2,0);
    ordered_insert(a1,n2,100);
    print_array(a1,n2,0);
}

void test_merge()
{
    cout << "======================================================" << endl;
    cout << "               Test Merge Function:" << endl;
    cout << "======================================================" << endl;
    int n1 = 4;
    int n2 = 4;
    int a1[] = {10,20,30,40};
    int a2[] = {15,25,35,45};
    cout << "Merge the following two arrays:" << endl;
    print_array(a1,n1,0);
    print_array(a2,n2,0);
    merge(a1,n1,a2,n2);
    print_array(a1,n1,0);
    cout << "check here" << endl;
    return;
    cout << "check here" << endl;
}

void test_copy()
{
    cout << "======================================================" << endl;
    cout << "                Test Copy Array:" << endl;
    cout << "======================================================" << endl;
    int n1 = 4;
    int n2 = 2;
    int a[] = {10,20,30,40};
    int a2[] = {15,25};
    cout << "Copy the first array into the second array:" << endl;
    print_array(a,n1,0);
    print_array(a2,n2,0);
    copy_array(a2,a,n2,n1);
    print_array(a2,n2,0);
    cout << "a2 size: " << n2 << " a1 size: " << n1 << endl;
}

void test_split()
{
    cout << "======================================================" << endl;
    cout << "               Test Split Array:" << endl;
    cout << "======================================================" << endl;
    int n1 = 3;
    int n2 = 0;
    int a[] = {10,20,30};
    int b[] = {};
    cout << "Split the following array:" << endl;
    print_array(a,n1,0);
    split(a,n1,b,n2);
    print_array(a,n1,0);
    cout << endl;
    print_array(b,n2,0);
}

void test_first_ge()
{
    cout << "======================================================" << endl;
    cout << "            Test First Greater in Array:" << endl;
    cout << "======================================================" << endl;
    int n = 4;
    int a[] = {10,20,30,40};

    int check_min = first_ge(a,n,5);
    int check_max = first_ge(a,n,100);
    cout << "Result: " << check_min << " " << check_max << endl;
}

void test_detach()
{
    cout << "======================================================" << endl;
    cout << "               Test Detach Function:" << endl;
    cout << "======================================================" << endl;
    int n = 4;
    int a[] = {10,20,30,40};
    cout << "Detach the following array:" << endl;
    print_array(a,n,0);
    int item = 0;
    detach_item(a,n,item);
    cout << " Result: " << item << " Size: " << n << endl;
}

void test_ascending()
{
    cout << "======================================================" << endl;
    cout << "             Test Is Ascending Function:" << endl;
    cout << "======================================================" << endl;
    int n = 10;
    int a[] = {10,12,20,20,30,40,60,78,98,1000};
    cout << "Is the following array in ascending order?"
         << endl;
    print_array(a,n,0);
    if ( is_ascending(a,n) ){
        cout << "Yes, is ascedning!" << endl;
    }
    else {
        cout << "No, isn't ascedning!" << endl;
    }

    int t = 10;
    int b[] = {10,12,20,2,30,40,60,78,98,1000};
    cout << "Is the following array in ascending order?"
         << endl;
    print_array(b,t,0);
    if ( is_ascending(b,t) ){
        cout << "Yes, is ascedning!" << endl;
    }
    else {
        cout << "No, isn't ascedning!" << endl;
    }
}

void test_is_gt()
{
    cout << "======================================================" << endl;
    cout << "               Test Is_gt Function:" << endl;
    cout << "======================================================" << endl;
    int n = 10;
    int a[] = {10,12,20,20,30,40,60,78,98,100};
    cout << "Is 200 always greater than the elements in the following array?"
         << endl;
    print_array(a,n,0);
    if ( !is_gt(a,n,200) ){
        cout << "Wrong, it's not always greater than" << endl;
    }
    else {
        cout << "Yes, it's always greater than" << endl;
    }
}

void test_is_le()
{
    cout << "======================================================" << endl;
    cout << "               Test Is_le Function:" << endl;
    cout << "======================================================" << endl;
    int n = 10;
    int a[] = {10,12,20,20,30,40,60,78,98,1000};
    cout << "Is 10 always less than the elements in the following array?"
         << endl;
    print_array(a,n,0);
    if ( !is_le(a,n,5) ){
        cout << "Wrong, it's not always less than" << endl;
    }
    else {
        cout << "Yes, it's always less than" << endl;
    }
}
