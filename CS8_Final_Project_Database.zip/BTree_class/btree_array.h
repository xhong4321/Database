#ifndef BTREE_ARRAY_H
#define BTREE_ARRAY_H

#include <iostream>
#include <vector>
using namespace std;

template <typename T>
T maximal(const T& a, const T& b);
//return the larger of the two items

template <typename T>
void swap(T& a, T& b);  //swap the two items

template <typename T>
int index_of_maximal(T data[ ], int n);
//return index of the largest item in data

template <typename T>
void shift_right ( T data[ ], int start, int& size );
//shift function for ordered_insert

template <typename T>
void shift_left ( T data[ ], int start, int& size );
//shift function for delete_item

template <typename T>
void ordered_insert(T data[ ], int& n, T entry);
//insert entry into the sorted array data with length n

template <typename T>
int first_ge(const T data[ ], int n, const T& entry);
//return the first element in data that is not less than entry

template <typename T>
void attach_item(T data[ ], int& n, const T& entry);
//append entry to the right of data

template <typename T>
void insert_item(T data[ ], int i, int& n, T entry);
//insert entry at index i in data

template <typename T>
void detach_item(T data[ ], int& n, T& entry);
//remove the last element in data and place it in entry

template <typename T>
void delete_item(T data[ ], int i, int& n, T& entry);
//delete item at index i and place it in entry

template <typename T> //merge is more like append
void merge(T data1[ ], int& n1, T data2[ ], int& n2);
//append data2 to the right of data1

template <typename T>
void split(T data1[ ], int& n1, T data2[ ], int& n2);
//move n/2 elements from the right of data1 and move to data2

template <typename T>
void copy_array(T dest[], const T src[],
                int& dest_size, int src_size);    //copy src[] into dest[]

template <typename T>
void print_array(const T data[], int n, int pos = 0);  //print array data

template <typename T>
bool is_gt(const T data[], int n, const T& item);       //item > all data[i]

template <typename T>
bool is_le(const T data[], int n, const T& item);       //item <= all data[i]

template <typename T>
bool is_ascending (const T data[ ], int n);
//check to see whether the array is in ascending order

//-------------- Vector Extra operators: ---------------------
//I'm not going to use these functions for BTree because these functions are
//for the Mmap (I have a header file for mmap's class)
//template <typename T>
//ostream& operator <<(ostream& outs, const vector<T>& list); //print vector list

//template <typename T>
//vector<T>& operator +=(vector<T>& list, const T& addme); //list.push_back addme


//============================================================================

template <typename T>
T maximal(const T& a, const T& b)    //return the larger of the two items
{
    if ( a < b ){
        return b;
    }
    return a;
}

template <typename T>
void swap(T& a, T& b)  //swap the two items
{
    T temp_a = a;
    T temp_b = b;
    a = temp_b;
    b = temp_a;
}

template <typename T>
int index_of_maximal(T data[ ], int n)
//return index of the largest item in data
{
    for ( int i = 0 ; i < n ; i++ ) {
        if ( is_gt(data,n,data[i]) ){
            return i;
        }
    }
}

template <typename T>
void shift_right ( T data[ ], int start, int& size )
//shift function for ordered_insert
{   //start is that position
    int temp_size = size;
    T temp[temp_size];
    copy_array(temp,data,temp_size,size);
    size++;
    int j = start + 1;
    for ( int i = start ; i < temp_size ; i++ ) {
        data[j++] = temp[i];
    }
}

template <typename T>
void shift_left ( T data[ ], int start, int& size )
//shift function for delete_item
{   //start is that position
    int temp_size = size;
    T temp[temp_size];
    copy_array(temp,data,temp_size,size);
    size--;
    int j = start + 1;
    int i = start;
    while ( j < temp_size ) {
        data[i++] = temp[j++];
    }
}

template <typename T>
void ordered_insert(T data[ ], int& n, T entry)
//insert entry into the sorted array data with length n
{
    bool added = false;
    for ( int i = 0 ; i < n ; i++ ) {
        if ( entry < data[i] ){
            //we find the item in the data array that greater than the entry
            shift_right(data,i,n);
            //such as: entry = 4, data = 1,2,3,4,5,6,7
            //we change data to: 1,2,3,4,4,5,6,7
            data[i] = entry;
            added = true;
            break;   //we dn't do anything else after we insert enntry
        }
    }
    if ( !added ){
        shift_right(data,n,n);
        data[n-1] = entry;
    }
}

template <typename T>
int first_ge(const T data[ ], int n, const T& entry)
//return the first element in data that is not less than entry
{
    bool found = false;
    for ( int i = 0 ; i < n ; i++ ) {
        if ( data[i] >= entry ){
            found = true;
            return i;
        }
    }
    if ( !found ){
        //it is importan to have this because when you have something larger
        //than everything you have to insert it in the end
        return n;
    }
}

template <typename T>
void attach_item(T data[ ], int& n, const T& entry)
//append entry to the right of data
{
    n++;
    int index = n - 1;
    data[index] = entry;
}

template <typename T>
void insert_item(T data[ ], int i, int& n, T entry)
//insert entry at index i in data
{
    shift_right(data,i,n); //n is already expanded
    data[i] = entry;
}

template <typename T>
void detach_item(T data[ ], int& n, T& entry)
//remove the last element in data and place it in entry
{
    int last_inde = n - 1;
    entry = data[last_inde];
    n--;
}

template <typename T>
void delete_item(T data[ ], int i, int& n, T& entry)
//delete item at index i and place it in entry
{
    entry = data[i];
    shift_left(data,i,n); //n is already shrinked
}

//template <typename T>
//void remove_item(T data[ ], int& n, const T& entry)
////delete item that is the same as entry
//{
//    for ( int i = 0 ; i < n ; i++ ) {
//        if ( data[i] == entry ){
//            shift_left(data,i,n); //n is already shrinked
//            break;
//        }
//    }
//}

template <typename T>
void merge(T data1[ ], int& n1, T data2[ ], int& n2)
//append data2 to the right of data1
{
    for ( int i = 0 ; i < n2 ; i++ ) {
        data1[n1++] = data2[i];
    }
    n2 = 0;     //shrink data2's size
  //  cout << "he " << n1 << " " << n2 << endl;
}

template <typename T>
void split(T data1[ ], int& n1, T data2[ ], int& n2)
//move n/2 elements from the right of data1 and move to data2
{
    int n = n1 / 2;   //we know how many items to be moved
    int index_1 = n1 - n;  //start from which index in data1
    int index_2 = n2;  //move to which index in data2
    n2 += n;   //expand data2's size
    for ( index_1 ; index_1 < n1 ; index_1++ ) {
        data2[index_2++] = data1[index_1];
    }
    n1 -= n; //shrink data1's size
}

template <typename T>
void copy_array(T dest[], const T src[],
                int& dest_size, int src_size)      //copy src[] into dest[]
{
    dest_size = src_size;
    for ( int i = 0 ; i < dest_size ; i++ ) {
        dest[i] = src[i];
    }
}

template <typename T>
void print_array(const T data[], int n, int pos)  //print array data
{
    //cout << n << " " << pos << endl;
    for ( int i = pos ; i < n ; i++ ) {
        cout << data[i] << " ";
    }
   // cout << endl << endl;
}

template <typename T>
bool is_gt(const T data[], int n, const T& item)  //item > all data[i]
{
    for ( int i = 0 ; i < n ; i++ ) {
        if ( item <= data[i] ){
            return false;
        }
    }
    return true;
}

template <typename T>
bool is_le(const T data[], int n, const T& item)   //item <= all data[i]
{
    for ( int i = 0 ; i < n ; i++ ) {
        if ( item > data[i] ){
            return false;
        }
    }
    return true;
}

template <typename T>
bool is_ascending (const T data[ ], int n)
{
    if ( n == 1 || n == 0 ){
        //This is very imortant because I spent 30 mintes here when I auto test
        //BTree.
        return true;
    }
    else {
        int count = 0;
        int i = 0;
        for ( int j = 1 ; j < n ; j++ ) {
            if ( data[j] >= data[i++] ){
                count++;
            }
        }
        if ( count == n-1 ){
            return true;
        }
        return false;
    }
}

//---------------------------------------------------------------------------

#endif // BTREE_ARRAY_H
