#include <iostream>
//#include "map.h"
#include "mmap.h"
using namespace std;

int main()
{
    cout << endl << endl << endl;

    //test_reading_and_writing_map_btree(); //GOOD
    //test_reading_and_writing_map_bpt(); //GOOD
    //test_reading_and_writing_mmap_btree(); //GOOD
    test_reading_and_writing_mmap_bpt(); //GOOD

    cout << endl << endl << "================End==============" << endl;
    return 0;
}
