#include "mmap.h"

void test_reading_and_writing_mmap_btree()
{
    cout << "=====================================" << endl;
    cout << "Test With BTree:" << endl;
    MMap<string,string> majors;
    majors["Jerry"] += "Mechanical Engineering";
    majors["Jerry"] += "Aerospace Engineering";
    majors["Link"] += "Computer Science";
    majors["Kevin"] += "Computer Science";
    majors["Nathan"] += "Math";
    majors["Tony"] += "civil Engineering";
    majors["Joanna"] += "Nursing";
    majors["Sheron"] += "Psychology";
    cout << "Test non-const get:" << endl << endl;
    cout << majors << endl;

    cout << "Test const get:" << endl << endl;
    test_const_mmap(majors,"Jerry");
}

void test_reading_and_writing_mmap_bpt()
{
    cout << "=====================================" << endl;
    cout << "Test With BplusTree:" << endl;
    MMap<string,string> majors;
    majors["Jerry"] += "Mechanical Engineering";
    majors["Jerry"] += "Aerospace Engineering";
    majors["Link"] += "Computer Science";
    majors["Kevin"] += "Computer Science";
    majors["Nathan"] += "Math";
    majors["Tony"] += "civil Engineering";
    majors["Joanna"] += "Nursing";
    majors["Sheron"] += "Psychology";
    cout << "Test non-const get:" << endl << endl;
    cout << majors << endl;

    cout << "Test const get:" << endl << endl;
    test_const_mmap(majors,"Jerry");

    cout << "Test for Iterator:" << endl;
    for ( MMap<string,string> :: Iterator it = majors.begin() ; it != majors.end() ; it++ ) {
        cout << *it << " ";
    }
    cout << endl;

//    MMap<int,int> test;
//    test[1] += 2;
//    test[3] +=4;
//    test[5] += 62;
//    test[7] +=45;
//    test[9] += 42;
//    test[13] +=24;

//    cout << test << endl;


}
