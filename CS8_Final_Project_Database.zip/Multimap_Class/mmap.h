#ifndef MMAP_H
#define MMAP_H


#include <iostream>
#include "mpair.h"
#include "../BplusTree/bplustree.h"
#include "vector_functions.h"
using namespace std;

template <typename K,typename V>
class MMap{
public:
    typedef BplusTree<MPair<K, V>> map_base;
    class Iterator{
        public:
        friend class MMap;
        Iterator(typename map_base::Iterator it);
        Iterator operator ++(int)
        {
            return _it++;
        }

        Iterator operator ++()
        {
            return ++_it;
        }

        MPair<K, V> operator *()
        {
            return *(_it);
        }

        friend bool operator ==(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._it == rhs._it ){
                return true;
            }
            return false;
        }

        friend bool operator !=(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._it != rhs._it ){
                return true;
            }
            return false;
        }

        private:
            typename map_base::Iterator _it;
        };

    MMap();

    Iterator begin();

    Iterator end();

    //  Iterators



    //  Modifiers

    void remove(const K& key);
    bool empty() const;
    bool contains(const MPair<K,V> target);
    void clear();


    const vector<V>& operator[](const K& key) const;
    vector<V>& operator[](const K& key);



//    Iterator find(const K& key);
    //int count(const K& key);
//    void insert(const K& k, const V& v);
//    bool is_valid();
//    int size() const;

    friend ostream& operator<<(ostream& outs, const MMap<K, V>& print_me){
        outs << print_me._mmap << endl;
        return outs;
    }

private:
    BplusTree<MPair<K,V>> _mmap;
};

//=================================================================
//                Definitions:
//=================================================================

template <typename K, typename V>
MMap<K,V> :: MMap()
{
    //blank
}

template <typename K, typename V>
void MMap<K,V> :: remove(const K& key)
{
    _mmap.remove(MPair<K,V>(key));
}

template <typename K, typename V>
bool MMap<K,V> :: empty() const
{
    return _mmap.empty();
}

template <typename K, typename V>
bool MMap<K,V> :: contains(const MPair<K,V> target)
{
    return _mmap.contains(target);
}

template <typename K, typename V>
void MMap<K,V> :: clear()
{
    _mmap.clear_tree();
}

template <typename K,typename V>
const vector<V>& MMap<K,V> :: operator[](const K& key) const
{
    return _mmap.get(MPair<K,V>(key,V())).value_list;
}

template <typename K,typename V> //direct access to the pair.value
vector<V>& MMap<K,V> :: operator[](const K& key)
//ability to read and write in the list
{
    return _mmap.get(MPair<K,V>(key)).value_list;
    //return a reference to the local scope
}

template <typename K,typename V>
typename MMap<K,V> :: Iterator MMap<K,V> :: begin ()
{
    return Iterator(_mmap.begin());
}

template <typename K,typename V>
typename MMap<K,V> :: Iterator MMap<K,V> :: end ()
{
    return Iterator(_mmap.end());
}

//=================================================================
//                Test Functions:
//=================================================================

void test_reading_and_writing_mmap_btree();
void test_reading_and_writing_mmap_bpt();

template <typename K,typename V>
//for checking the const version subscript operator
void test_const_mmap(const MMap<K,V>& m, const string& s)
{
    if ( !m.empty() ){
        cout << s << ": " << m[s] << endl;
    }
}

#endif // MMAP_H
