#ifndef Z_OUTPUT_H
#define Z_OUTPUT_H

/*
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 * ALL RESULTS HAVE BEEN VERIFIED
 *
 *
 *
 *

what's up bro!
Test Parser Class: select * from emp
pos : 17
pos : 17
We get a from
    [table : emp]
    [field : *]
[field : *]
    [command : select]


congrats!


================End===============
Press <RETURN> to close this window...
 *
 *
 *
 *
 *
 *
 *
 */

#endif // Z_OUTPUT_H
