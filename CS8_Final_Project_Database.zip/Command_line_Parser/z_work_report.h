#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H

/*
Features:

    -Not Implemented: None.

    -Implemented: This program at this point can manpluate ctor. And ctor
    contains init state machine, set string, get parse tree, get column, and
    build keyword list.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
    After finishing this progress, I had a better idea of how to combine
    different projects together to do some more interesting stuff. The hardest
    part of this is to make sure that all your lower level functions are
    correct. I found out my overloading vector functions were wrong when I
    wrote subscript operator +=, and it was because I didn't have a
    template<typename T, tyename U> for my operator +=.
*/

#endif // Z_WORK_REPORT_H
