/*
 * Author: Xiangyu Hong
 * Project: SQL - Parser Class
 * Purpose: The purpose of this program is to create a Parser class which
 * transform a line of command into Ptree Multimap structure
 * Notes: I only used select * from emp to test the Table Class
*/

#include <iostream>
#include "parser.h"
using namespace std;

int main()
{
    cout << endl << endl << endl;

    cout << "what's up bro!" << endl;

    test_parser_class();

    cout  << "congrats!" << endl;

    cout << endl << endl << "================End===============" << endl;
    return 0;
}
