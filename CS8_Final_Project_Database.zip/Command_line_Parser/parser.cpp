#include "parser.h"

Parser::Parser()
{
    //blank
    valid_ptree = false;
    strcpy(buffer,"");
    init_make_table();
}

Parser :: Parser (char* s)
{
    valid_ptree = false;
 //   cout << 11111 << endl;
    strncpy(buffer,s,MAX_VALUE);
 //   cout << 2222 << endl;
    init_make_table();
 //   cout << 333333 << endl;
    build_keyword_list();
 //   cout << 44444 << endl;
    set_string();
 //   cout << 55555 << endl;
}

void Parser :: init_make_table()
{
    //I'm building the table for "select * from emp"
    init_table(adjacency_table);
    //----------------------------------------------
    //My Make and Create Assembly Line
    for ( int i = 0  ; i < 5 ; i++ ) {
        mark_fail(adjacency_table,i);
    }
    mark_success(adjacency_table,5);
    //----------------------------------------------

    //----------------------------------------------
    //My insert into Assembly Line
    mark_fail(adjacency_table,10);
    mark_fail(adjacency_table,11);
    mark_fail(adjacency_table,12);
    mark_success(adjacency_table,13);
    mark_success(adjacency_table,14);
    mark_fail(adjacency_table,15);//" left
    //----------------------------------------------

    //----------------------------------------------
    //My select Assembly Line
    mark_fail(adjacency_table,20);
    mark_fail(adjacency_table,21);
    mark_fail(adjacency_table,22);
    mark_success(adjacency_table,23);
    mark_success(adjacency_table,24);
    mark_success(adjacency_table,25);
    mark_fail(adjacency_table,26);
    mark_fail(adjacency_table,27);
    mark_success(adjacency_table,30);
    mark_success(adjacency_table,31);
    //----------------------------------------------



    mark_cell(0,adjacency_table,SELECT,20); //"select (1)-> *"
    mark_cell(0,adjacency_table,CREATE,1); //"create (9)-> table"
    mark_cell(0,adjacency_table,MAKE,1); //"make "

    mark_cell(1,adjacency_table,TABLE,2);
    mark_cell(2,adjacency_table,SYMBOL,3);
    mark_cell(3,adjacency_table,FIELDS,4);
    mark_cell(4,adjacency_table,SYMBOL,5);
    mark_cell(5,adjacency_table,COMMA,4);

    mark_cell(0,adjacency_table,INSERT,10);
    mark_cell(10,adjacency_table,INTO,11);
    mark_cell(11,adjacency_table,SYMBOL,12);
    mark_cell(12,adjacency_table,VALUES,13);
    mark_cell(13,adjacency_table,SYMBOL,14);

    mark_cell(13,adjacency_table,COMMA,13);

    mark_cell(14,adjacency_table,COMMA,13);
    mark_cell(13,adjacency_table,QUOTATION,15); //no need to care
    mark_cell(15,adjacency_table,COMMA,13); //no need to care

    mark_cell(20,adjacency_table,SYMBOL,26);
    mark_cell(26,adjacency_table,COMMA,27);
    mark_cell(27,adjacency_table,SYMBOL,26);
    mark_cell(26,adjacency_table,FROM,22);
    //"star "
    mark_cell(20,adjacency_table,STAR,21);
    mark_cell(22,adjacency_table,SYMBOL,25);
    //"from "
    mark_cell(21,adjacency_table,FROM,22);
    //"symbol "
    mark_cell(22,adjacency_table,SYMBOL,23);
    mark_cell(23,adjacency_table,WHERE,24);
    mark_cell(24,adjacency_table,SYMBOL,25);
    mark_cell(24,adjacency_table,LEFT_PARENTHESES,25);
    mark_cell(25,adjacency_table,SYMBOL,25);
    mark_cell(25,adjacency_table,QUOTATION,25); // no need to care
    mark_cell(25,adjacency_table,LEFT_PARENTHESES,25);
    mark_cell(25,adjacency_table,RIGHT_PARENTHESES,25);
    mark_cell(25,adjacency_table,LESS_THAN,25);
    mark_cell(25,adjacency_table,GREATER_THAN,25);
    mark_cell(25,adjacency_table,EQUAL,25);

    mark_cell(0,adjacency_table,BATCH,30);
    mark_cell(30,adjacency_table,SYMBOL,31);
}

void Parser :: build_keyword_list()
{
    //I'm building the keyword for "select * from emp"
    _keywords["SELECT"] = SELECT;
    _keywords["*"] = STAR;
    _keywords["FROM"] = FROM; // useless
    _keywords["CREATE"] = CREATE;
    _keywords["MAKE"] = MAKE;
    _keywords["FIELDS"] = FIELDS; // useless
    _keywords[","] = COMMA;
    _keywords["TABLE"] = TABLE; // useless
    _keywords["INSERT"] = INSERT;
    _keywords["INTO"] = INTO;
    _keywords["VALUES"] = VALUES; // useless
    _keywords["\""] = QUOTATION;
    _keywords["WHERE"] = WHERE;
    _keywords["<"] = LESS_THAN;
    _keywords[">"] = GREATER_THAN;
    _keywords["="] = EQUAL;
    _keywords["("] = LEFT_PARENTHESES;
    _keywords[")"] = RIGHT_PARENTHESES;
    _keywords["BATCH"] = BATCH;
//    _keywords["symbol"] = SYMBOL; //if !contains, it is a symbol
}

void Parser :: set_string()
{
   // cout << buffer << endl;

    STokenizer skt(buffer);
    S_Token t;
    skt >> t;
    while ( !skt.done() ) {
        if ( t.type_string() != "SPACE" ){ //I don't need space
   //         cout << "tokenizer: " << t.token_str() << endl;
            input_q.push_back(t.token_str());
        }

        t = S_Token();
        skt >> t;
    }
    if ( t.token_str() != " " ){
        input_q.push_back(t.token_str()); //to push_back the last token string
    }


    if ( get_parse_tree() ){
        MMap<string,string> test = parse_tree();
    }

  //  cout << "Check my Ptree:" << endl;
  //  cout << Ptree << endl;

   // cout << "He: " << Ptree["values"][4] << endl;
}

void Parser :: set_string ( string command )
{
    strncpy(buffer,command.c_str(),MAX_VALUE);
    init_make_table();
    build_keyword_list();
    set_string();
}

int Parser :: get_column(string token)
{
    if ( _keywords.contains(token) )
    {
        return _keywords[token];
    }
    else {
        return SYMBOL;
    }
}

bool Parser::get_parse_tree()
{
    unsigned int index = 0;
    int state = 0;
    string token;
//    cout << "IIIIIIIIIIIIIIII " << input_q.size() << endl;
    while ( ( index < input_q.size() ) && ( !is_fail(adjacency_table,state) )) {
        token = input_q[index++];
    //    cout << "test: " << token << endl;

        if ( token == "\""){ //deal with the quotation!
    //        cout << "come in??" << endl;
            string str = input_q[index++];
            string temp =  str;
            while ( input_q[index++] != "\"" ) { //good
    //            cout << "come inXXXXXXX" << endl;
                string s = input_q[--index];
                if ( s == "." ){
                    temp += s;
                }
                else {
                    temp += " ";
                    temp += s;
                }
                index++; //it'simportant!!!!!!!!!!!
            } //input_q == "
            if ( state == 13 ){ // in insert
   //             cout << "Test temp: " << temp << endl;
                Ptree["values"] += temp;
            }
            else
            { // in select
                Ptree["conditions"] += temp;
            }
        }
        else if ( token == "BATCH" ) {
            Ptree["command"] += token;
            string str = input_q[index++];
   //         cout << "check: " << str << endl;
            string temp =  str;
            while ( index < input_q.size() ) {
              //  cout << "come inXXXXXXX" << endl;
                temp += input_q[index++];
    //            cout << "check 2: " << temp << endl;
            } //input_q == "
            Ptree["file_name"] += temp;
            state = 31;
        }
        else {
            //convert the token into all Upper case
            string temp_str = token;
            for_each(temp_str.begin(), temp_str.end(), [](char & c) {
                c = toupper(c);
            });
     //       cout << "Result: " << token << endl;
            int i = get_column(temp_str);
            state = adjacency_table[state][i];

            switch ( state ) {
            case 1:
                Ptree["command"] += token;
                break;
            case 2:
   //             cout << "We gwt a " << token << endl;
                break;
            case 3:
                Ptree["table"] += token;
                break;
            case 4:
   //             cout << "We get a " << token << endl;
                break;
            case 5:
                Ptree["fields"] += token;
                break;
            case 10:
                Ptree["command"] += token;
                break;
            case 11:
                Ptree["command"] += token;
                break;
            case 12:
                Ptree["table"] += token;
                break;
            case 13:
   //             cout << "We get a " << token << endl;
                break;
            case 14:
                Ptree["values"] += token;
                break;
            case 20: // select
                Ptree["command"] += token;
                break;
            case 21: //star
                Ptree["fields"] += token;
                break;
            case 22: //from
    //            cout << "We get a " << token << endl;
                break;
            case 23: //
                Ptree["table"] += token;
                break;
            case 24: //where
  //              cout << "We get a " << token << endl;
                break;
            case 25: //to make >= and <=
                if ( token == ">" || token == "<" ){
                    string temp = input_q[index++];
                    if ( temp == "=" ){
                        token += temp;
                        Ptree["conditions"] += token;
                        int i = get_column(temp);
                        state = adjacency_table[state][i];
                    }
                    else {
                        Ptree["conditions"] += token;
                        --index;
                    }
                }
                else {
                    Ptree["conditions"] += token;
                }
                break;
            case 26:
                Ptree["fields"] += token;
                break;
            case 27:
  //              cout << "We get a " << token << endl;
                break;
            default:
  //              cout << "Wrong place, bro!!!!"<<endl;
                break;
            }
        }
    }

    if ( is_success(adjacency_table,state) ){
  //      cout << "This Ptree is valid" << endl;
        valid_ptree = true;
        return true;
    }
    else {
        Ptree.clear();
 //       cout << "This Ptree is invalid!!!!!!" << endl;
        valid_ptree = false;
        return false;
    }
}

MMap<string,string> Parser :: parse_tree()
{
    if ( is_ptree_valid() ){
        return Ptree;
    }
    else {
        return MMap<string,string>();
    }
}

void test_parser_class()
{
//    Table t("emp",{"Last","First","Major"});
//    t.insert_into({"Jones","Bill","CS"});
//    t.insert_into({"Smith","Nancy","Civil"});
//    t.insert_into({"Jerry","Hong","Aerospace"});
//    t.insert_into({"Kevin","Li","CS"});
//    t.insert_into({"Nathan","Tong","Math"});
//    cout << t.select_all() << endl;
//    cout << "Test Parser Class: select * from emp " <<endl;
//    Parser p("select * from emp");

//    string str;
//    cout << "> ";
//    cin >> str;
//    cout << str;



    char input[100000];
    cout << "> ";
    cin.getline(input,sizeof (input));
    cout << "size: " << sizeof(input) << endl;



    Parser p(input);
    cout << p.parse_tree().size() << endl;
    cout << "check 1" << endl;
//    MMap<string,string> ptree = p.parse_tree();
//    cout << "check 2" << endl;
//    if ( ptree["command"][0] == "select" ){
//        cout << "check 3" << endl;
//        string table_name = ptree["table"][0];
//        cout << table_name << endl;
//        Table t(table_name);
//        if ( ptree["field"][0] == "*" ){
//           // cout << "good" << endl;
//            cout << t.select_all() << endl;
//        }
//    }
//    else if ( ptree["command"][0] == "make" || ptree["command"][0] == "create" ) {
//        cout << "check 4" << endl;
//        for ( int i = 0 ; i < ptree["fields"].size() ; i++ ) {
//            cout << ptree["fields"][i] << endl;
//        }
//        Table t(ptree["table"][0],ptree["fields"]);
//        cout << t.select_all() << endl;
//    }




    //cout << str.size() << endl;
//    char arr[] = "";
//    strcpy(arr,str.c_str());
//    for ( int i = 0 ; i < strlen(arr) ;i++  ) {
//        cout << arr[i];
//    }
    //Parser p(arr);



//    Parser p(str.c_str());

   // Parser p("make table employee fields last, first, dep, salary, year");

   // Parser p("select * from student where lname = Jackson");

   // Parser p("select * from employee where last = Jackson and year < 2015");

   // Parser p("select * from employee where dep = CS or year >2014 and year < 2018 or salary >= 265000");


//
 //   cout << "input length: " << n << endl;
//    char ch_arr[100];


//    strcpy(ch_arr, str.c_str());

//    for (int i = 0; i < 100 ; i++) {
//        cout << ch_arr[i];
//    }
//    cout << "F" << endl;

 //   Parser p(ch_arr);




//    char charr[str.length()];

//    int i;
//    for (i = 0; i < sizeof(str); i++) {
//        charr[i] = str[i];
//        cout << charr[i];
//    }

//    Parser p(charr);

//    Parser p("insert into employee values Jones, Bo, CS, 10000, 2018");


}









