#ifndef PARSER_H
#define PARSER_H

#include <iostream>
//#include "../BPT_Map_and_Multi_Map_classes/multi_map.h"
//#include "../BPT_Map_and_Multi_Map_classes/map.h"
//#include "../BPT_Map_and_Multi_Map_classes/overloading_vector_func.h"
#include "../state_machines/state.h"
#include "../string_tokenizer/stokenizer.h"
#include "../string_tokenizer/stz_token.h"
#include "../Table_Class/table.h"
#include "../Table_2d_record/record_2d.h"
#include <string>
#include <algorithm>
using namespace std;

const int MAX_VALUE = 100;
const int SUCCESS = 0;
const int SELECT = 1;
const int STAR = 2;
const int FROM = 3;
const int CREATE = 4;
const int MAKE = 5;
const int FIELDS = 6;
const int COMMA = 7;
const int TABLE = 8;
const int INSERT = 9;
const int INTO = 10;
const int VALUES = 11;
const int QUOTATION = 12;
const int WHERE = 13;
const int LESS_THAN = 14;
const int GREATER_THAN = 15;
const int EQUAL = 16;
const int LEFT_PARENTHESES = 17;
const int RIGHT_PARENTHESES = 18;
const int BATCH = 19;
const int SYMBOL = 20;
//const int FILE_NAME = 21;


class Parser
{
public:
    Parser();
    Parser (char* s);

    void init_make_table();
    void set_string();
    void set_string ( string command );
    bool get_parse_tree();
    MMap<string,string> parse_tree();
    int get_column(string token);
    void build_keyword_list();
    bool is_ptree_valid() {return valid_ptree;}

private:
    MMap<string,string> Ptree;
    Map<string,int> _keywords;
    char buffer[MAX_VALUE];
    int adjacency_table[MAX_ROWS][MAX_COLUMNS]; //max consts are from state.h
    vector<string> input_q;
    bool valid_ptree;
   // enum keys {SUCCESS, SELECT, FROM, WHERE, STAR,  SYMBOL};

};

void test_parser_class();

#endif // PARSER_H
