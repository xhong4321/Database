#ifndef SQL_H
#define SQL_H

#include <iostream>
#include <fstream>
#include "../Command_line_Parser/parser.h"
#include "../BPT_Map_and_Multi_Map_classes/map.h"
#include "../Table_Class/table.h"
#include <vector>
using namespace std;

class SQL
{
public:
    SQL();
    
    void run();
    void run_command(char* command, int& i);
    void run_batch(char* file_name);
    
    
private:
   // Parser _parser;
    Map<vector<string>,Table> _tables; //SQL has to know which it is keeping track of
};

#endif // SQL_H
