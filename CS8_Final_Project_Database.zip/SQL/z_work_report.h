#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H

/*
Features:

    -Not Implemented: None.

    -Implemented: This program can do create and make table, insert into
    values, select all which is print the entire table, select simple
    conditions where we have limited of one condition, select from where which
    we can have mutliple conditions, we can use relational operators and
    logical operators, and left and right parentheses.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
  This project is heavily based on some projects we did before. For example,
   BplusTree, MMap, Map, Parser, Table, shunting yard, rpn, state machine,
   string tokenizer, and I even used inherentce. It is a hard project, but I'm
   glad that i finish this project with  perfect output. I suffered from
   finding the linker error and that copy ctor error for many days, but I'm
   able to get over those and move on to finish the assignment. While I was
   doing this project, i ahve more and more clear idea of how previous projects
   are, and I was able to find the error immedoiately because I have more clear
   understanding of each project as time goes along. The most hardest part
   is to connect each project together and make sure no same names. I had two
   Token class before, but I already fixed it by changing one name to stz_Token
   which represents the Token for string Tokennizer. Overall, it's a challenging
   project. But I enjoyed the challenge.
*/

#endif // Z_WORK_REPORT_H
