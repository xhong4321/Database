 #include "sql.h"

SQL::SQL()
{
    //I'm gonna push some table names and corresponding Tables into _tables

}

void SQL :: run()
{
//    cout << "------ SQL Tables I Manage: --------" << endl;
//    cout << "employee" << endl;
//    cout << "student" << endl;
//    cout << "------------------------------------" << endl;

    int i = 0;
    char input[100];
    cout << "> ";
    cin.getline(input,sizeof(input));
    while ( input != "X" || input != "x" ) {

        run_command(input,i);
        i++;
        cout << "> ";
        cin.getline(input,sizeof(input));
    }

}

void SQL ::  run_batch(char* file_name)
{
   // cout << "WHAT's UPPPPPPPPPPPPP?" << endl;
    ifstream in_stream;
    in_stream.open(file_name);

    if(in_stream.fail()){
        cout <<"Input file opening failed. \n";
        exit(2);
    }

  //  char input[100];
    string str;
    int i = 0;
    while ( !in_stream.eof() ) {
        getline(in_stream,str);

        char cstr[str.size() + 1];
        strcpy(cstr, str.c_str());
        run_command(cstr,i);
        // cout << str.length() << endl;
        i++;
//        cout << cstr << endl;
    }
    in_stream.close();
}

void SQL :: run_command(char* command, int& i)
{
    if ( command[0] == '/' ){ //The comments
        cout << command << endl;
        i--;
    }
    else if ( command[0] == '\0' ) { //The empty lines
        cout << endl;
        i--;
    }
    else {
        cout << "[" << i << "]" << command << endl << endl;

//        assert(1== 0);

        Parser p(command);
 //       cout << "check 1" << endl;
        MMap<string,string> ptree = p.parse_tree();

        if ( ptree["command"][0] == "BATCH" ){
            string file_name = ptree["file_name"][0];//only for batch
            char arr[] = "";
            strcpy(arr,file_name.c_str());
            run_batch(arr);
 //           cout << endl << endl << "!!!!!!finished!!!!!" << endl;
        }
        else if ( ptree["command"][0] == "select" ){
   //         cout << "check 3" << endl;
          //  string table_name = ptree["table"][0];
//            cout << table_name << endl;
           // Table t(table_name);
            if ( ptree["fields"][0] == "*" ){
    //            cout << "check 88888: " << endl;
                if ( ptree.size() == 4 ){
      //               cout << "goodggggggggodgodgdgdgdo" << endl;
                    Table t(ptree["table"][0]);
                    cout << t.select_all() << endl;
                    cout << endl << endl << "SQL: DONE." <<endl;
                }
                else if ( ptree["conditions"].size() == 3 ) {
                    Table t(ptree["table"][0]);
    //                cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
                    cout << t.select_simple_condition(ptree["conditions"]);
                    cout  << endl << endl << "SQL: DONE." <<endl;
  //                  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
                }
                else {
   //                 cout << "LLLLLLLLL: " << endl;
                    Table t(ptree["table"][0]);
                    cout << t.select_cond(ptree["conditions"]);
                    cout << endl << endl << "SQL: DONE." <<endl;
                }
            }
            else { //
                if ( ptree["conditions"].size() == 3 ) {
                    Table t(ptree["table"][0]);
                    cout << t.select_secondary_simple(ptree["fields"],ptree["conditions"]);
                    cout << endl << endl << "SQL: DONE." <<endl;
                }
                else {
                    Table t(ptree["table"][0]);
                    cout << t.select(ptree["fields"],ptree["conditions"]);
                    cout << endl << endl << "SQL: DONE." <<endl;
                }
            }
        }
        else if ( ptree["command"][0] == "make" || ptree["command"][0] == "create" ) {
 //           cout << "check 4:~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
//            for ( int i = 0 ; i < ptree["fields"].size() ; i++ ) {
//                cout << ptree["fields"][i] << endl;
//            }
            Table t(ptree["table"][0],ptree["fields"]);
            t.information(ptree["command"][0]);
            cout << endl << "SQL: DONE." <<endl;
           // cout << t.select_all() << endl;
        }
        else { //insert into
   //         cout << "check 5" << endl;
            Table t(ptree["table"][0]);
            t.insert_into(ptree["values"]);
            cout << "SQL::run: inserted." << endl;
            cout << endl << endl << "SQL: DONE." <<endl;
           // cout << t.select_all() << endl;
        }
    }
  //  _parser.set_string(command);

}














