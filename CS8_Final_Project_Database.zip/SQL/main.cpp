/*
 * Author: Xiangyu Hong
 * Project: CS8 Final Project
 * Purpose: The purpose of this program is to create a SQL class which is
 * heavily based on our BplusTree, MMap, Map, Parser, Table, shunting yard,
 * rpn, state machine, string tokenizer.
 * Notes: I ran this project using professor's txt file, and it worked
 * perfectly
*/

#include <iostream>
#include "sql.h"
using namespace std;

int main()
{
    cout << endl << endl << endl;

    cout << "what's up bro!" << endl;

    SQL sql;
    sql.run();

    cout  << "congrats!" << endl;

    cout << endl << endl << "================End===============" << endl;
    return 0;
}
