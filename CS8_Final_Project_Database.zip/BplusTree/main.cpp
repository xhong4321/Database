/*
 * Author: Xiangyu Hong
 * Project: BT B+ Tree Progress II
 * Purpose: The purpose of this program is to create a BplusTree class which is
 * heavily based on our BTree class. We make sure to finish insert, get,
 * contains, find, clear, copy, iterator, linked list, and remove functions.
 * Notes: I only used integer to test the pogram
*/

#include <iostream>
#include "bplustree.h"
using namespace std;

int main()
{
    srand(time(0));
    cout << endl << endl << endl;

    cout << "what's up bro!" << endl;

    //test_insert(); //GOOD
    test_get_and_contains(); //GOOD
    //test_copy_and_clear(); //GOOD
    //test_big_three(); //GOOD
    //test_count_size(); //GOOD
    //test_remove_poorman(); //GOOD
    //test_remove_regular(); //GOOD
    //test_remove_randomly(); //GOOD
    //test_BplusTree_auto(1000,100,false); //Good

    cout  << "congrats!" << endl;

    cout << endl << endl << "================End===============" << endl;
    return 0;
}
