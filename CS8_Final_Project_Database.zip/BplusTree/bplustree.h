#ifndef BPLUSTREE_H
#define BPLUSTREE_H


#include <iostream>
#include "../BTree_class/btree_array.h"
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

template <typename T>
class BplusTree
{
public:

    //------------------------------------------------------------------------
    class Iterator{
    public:
        friend class BplusTree;

        Iterator( BplusTree<T>* ptr=nullptr, int key=0):_ptr(ptr),_key(key)
        {
            //blank
        }

//        T& operator *()
//        {
//            assert(_ptr);
//            return _ptr->data[_key];
//        }

        T* operator ->()
        {
            return &(_ptr->data[_key]);
        }

        const T& operator *() const
        {
            assert(_ptr);
            return _ptr->data[_key];
        }

        operator bool()
        {
            if (_ptr == nullptr){
                return true;
            }
            return false;
        }

        bool is_null()
        {
            if (_ptr == nullptr){
                return true;
            }
            return false;
        }

        Iterator& operator++() //member operator: ++it
        {
            _key++;
            if(_key == _ptr->data_count){ //_key ia at the end
                _key = 0;
                _ptr = _ptr->_next;
            }
            return *this;
        }

        Iterator operator++(int)
        {                                   //friend operator: it++
            Iterator hold;
            hold = *this;
            this->_key++;
            if ( this->_key == this->_ptr->data_count ){
                this->_key = 0;
                this->_ptr = this->_ptr->_next;
            }
            return hold;
        }

        friend bool operator ==(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._ptr == rhs._ptr ){
                return true;
            }
            return false;
        }

        friend bool operator !=(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._ptr != rhs._ptr ){
                return true;
            }
            return false;
        }


    private:
        const BplusTree<T>* _ptr;
        int _key;
    };
    //-----------------------------------------------------------------------

    BplusTree(bool dups = false);

    //big three:
    BplusTree(const BplusTree<T>& other);
    ~BplusTree();
    BplusTree<T>& operator =(const BplusTree<T>& RHS);

    //-----------------------------------------------
    Iterator begin();
    Iterator begin() const;

    Iterator end();
    Iterator end() const;

    Iterator find(const T& entry);
    //return an iterator to this key. NULL if not there.

    Iterator lower_bound(const T& key);  //return first that goes NOT BEFORE
                                             // key entry or next if does not
                                             // exist >= entry
    Iterator upper_bound(const T& key);  //return first that goes AFTER key

    //------------------------------------------------

    void insert(const T& entry);
    //insert entry into the tree
    void remove(const T& entry);
    //remove entry from the tree

    void clear_tree();
    //clear this object (delete all nodes etc.)
    void copy_tree(const BplusTree<T>& other);
    void copy_tree(const BplusTree<T>& other, BplusTree<T>* &last_leaf );
    //copy other into this object

    bool contains(const T& entry);
    //true if entry can be found in the array

    const T& get(const T& entry) const;
    T& get(const T& entry);
    //return a reference to entry in the tree


    int size() const;
    //count the number of elements in the tree
    bool empty() const;
    //true if the tree is empty
    bool is_valid(bool is_root = true);  //By default, it 's true for the root

    void print_tree(int level = 0, ostream &outs=cout) const;
    //print a readable version of those tree
    friend ostream& operator<<(ostream& outs, const BplusTree<T>& print_me){
        print_me.print_tree(0, outs);
        return outs;
    }


private:
    static const int MINIMUM = 1;
    static const int MAXIMUM = 2 * MINIMUM;

    bool dups_ok;                     //true if duplicate keys may be inserted
    int data_count;                                 //number of data elements
    T data[MAXIMUM + 1];                            //holds the keys
    int child_count;                                //number of children
    BplusTree* subset[MAXIMUM + 2];                     //subtrees
    BplusTree* _next;

    BplusTree<T>* get_smallest_node();
    BplusTree<T>* get_smallest_node() const;

    T* find_ptr(const T& entry);
    //return a pointer to this key. NULL if not there

    bool is_leaf() const;
    //true if this is a leaf node

    //insert element functions
    void loose_insert(const T& entry);
    //allows MAXIMUM+1 data elements in the root
    void fix_excess(int i);
    //fix excess of data elements in child i

    T& get_existing(const T& entry);

    //remove element functions:
    void loose_remove(const T& entry);
    //allows MINIMUM-1 data elements in the root
    BplusTree<T> *fix_shortage(int i);
    //fix shortage of data elements in child i
    void get_smallest(T& entry);        //entry := leftmost leaf
    void transfer_left(int i);
    //transfer one element LEFT from child i
    void transfer_right(int i);
    //transfer one element RIGHT from child i
    BplusTree<T> *merge_with_next_subset(int i);
    //merge subset i with subset i+1
};

//===========================================================================

template<typename T>
BplusTree<T> :: BplusTree(bool dups){
    dups_ok = dups;
    data_count = 0;
    child_count = 0;
    _next = nullptr;
}

//big three:
template<typename T>
BplusTree<T> :: BplusTree(const BplusTree<T>& other)
{
    child_count = 0;
    data_count = 0;

    copy_tree(other);
}

template <typename T>
BplusTree<T>& BplusTree<T> :: operator =(const BplusTree<T>& RHS)
{
    //check for self-reference
    if ( this == &RHS ){
        return *this;
    }
    //call function to clear this object.
    clear_tree();
    //call function to copy rhs into this object
    copy_tree(RHS);
    return *this;
}

template <typename T>
BplusTree<T> :: ~BplusTree()
{
    clear_tree();
}

template <typename T>
void BplusTree<T> :: clear_tree()  //clear this object (delete all nodes etc.)
{
    //it's not ok to use data->is_leaf because member reference base type 'int'
    //is not a structure or object
    if ( !is_leaf() ){
        for ( int i = 0 ; i < child_count ; i++ ) {
            subset[i]->clear_tree();
            delete subset[i];
        }
    }
    child_count = 0;
    data_count = 0;
}

//--------------------------------------------------------------------------
template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: begin()
{
    return Iterator(get_smallest_node());
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: begin() const
{
    return Iterator(get_smallest_node());
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: end()
{
    return Iterator(nullptr,0);
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: end() const
{
    return Iterator(nullptr,0);
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: find(const T& entry)
//return an iterator to this key. NULL if not there.
{
    if ( find_ptr(entry) != nullptr ){
        return Iterator(find_ptr(entry));
    }
    return Iterator(NULL);
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: lower_bound(const T& key)
//return first that goes NOT BEFORE
//key entry or next if does not exist >= entry
{

   // if ( contains(key) ){
        for ( BplusTree<T> :: Iterator it = begin() ; it != end() ; it++ ) {
            if ( *it >= key  ){ //In select simple condition, we might use != lower_bound to represent <
                return it;      //In select simple condition, we might use = lower_bound to represent <=
            }
        }
   // }
  //  else {
        return Iterator(nullptr,0);
  //  }
}

template<typename T>
typename BplusTree<T> :: Iterator BplusTree<T> :: upper_bound(const T& key)
//return first that goes AFTER key
{
   // cout << "Father" << endl;
 //   if ( contains(key) ){
        for ( BplusTree<T> :: Iterator it = begin() ; it != end() ; it++ ) {
         //   cout << "BplusTree upper: " << *it << endl;
          //  cout << "dsffbdbsddjdiihd" << endl;
            if ( *it > key ){ //the first goes after key
                return it;
            }
        }
  //  }
  //  else {
        return Iterator(nullptr,0);
  //  }
}

template <typename T>
BplusTree<T>* BplusTree<T> :: get_smallest_node()
{
    if (!is_leaf()){
        return subset[0]->get_smallest_node();
    }
    else {
        return (BplusTree<T>*)this;
    }
}

template<typename T>
BplusTree<T>* BplusTree<T> :: get_smallest_node() const
{
    if (!is_leaf()){
        return subset[0]->get_smallest_node();
    }
    else {
        return (BplusTree<T>*)this;
    }
}
//----------------------------------------------------------------------------

template <typename T>
void BplusTree<T> :: copy_tree(const BplusTree<T>& other )
//I declare this function so that I can have the prev_leaf = nullptr
//copy other into this object
{
    BplusTree<T>* prev_leaf = nullptr;
    copy_tree(other,prev_leaf);
}

template <typename T>
void BplusTree<T> :: copy_tree(const BplusTree<T>& other, BplusTree<T>* &last_leaf )
//copy other into this object
{

 //   if (!other.is_leaf()){ //i am not a leaf
        copy_array(data,other.data,data_count,other.data_count);
        //it's important to remember to copy the chid_count
        child_count = other.child_count;
        if ( !other.is_leaf() ){
            for ( int i = 0 ; i < child_count ; i++ ) {

                subset[i] = new BplusTree<T>();
                //insert_item(this->subset[i],i,this->child_count,new_node);
                subset[i]->copy_tree(*other.subset[i],last_leaf);
                                   //it might be a lot of subtrees
            }
        }
        else {
            if ( last_leaf == nullptr ){
                BplusTree<T>* myself = new BplusTree<T>();
                myself = other.get_smallest_node();
                //set the last_leaf to this node
                last_leaf = this;
            }
            else {
                //link the prev_leaf to this node
                last_leaf->_next = this;
                last_leaf = last_leaf->_next;
            }
        }
}

//------------------------------------------------
//          I N S E R T
//------------------------------------------------
template <typename T>
void BplusTree<T> :: insert(const T& entry){
    //in order for this class to be able to keep track of the number of the
    //keys, this function (and the functions
    //  it calls ) must return a success code.
    //If we are to keep track of the number the keys (as opposed to key/values)
    //then the success
    //  code must distinguish between inserting a new key, or adding a new key
       //to the existing key.
    //  (for "dupes_ok")
    //
    //loose_insert this entry into this root.
    //loose_insert(entry) will insert entry into this tree. Once it returns,
    //all the subtrees are valid
    //  btree subtrees EXCEPT this root may have one extra data item:
    //    in this case (we have excess in the root)
    //      create a new node, copy all the contents of this root into it,
    //      clear this root node,
    //      make the new node this root's only child (subset[0])
    //
    //Then, call fix_excess on this only subset (subset[0])
    loose_insert(entry);
    //cout << "he!: " << data_count << endl;
    //loose insert will take whatever entry and my parent just take it; then,
    //I have to use grow tree to modify it so that my parent is not too large
    if ( data_count > MAXIMUM ){       //grow tree
        BplusTree<T>* new_node = new BplusTree<T>();
        //new_node->copy_tree(data);
        copy_array(new_node->data,data,new_node->data_count,data_count);
        copy_array(new_node->subset,subset,new_node->child_count,child_count);
//        cout << "data: " << data_count << "child " << child_count << endl;
  //  clear_tree(); //Don't clear the tree, it's gonna confuse the whole stuff
//        cout << "data: " << data_count << "child " << child_count << endl;
        data_count = 0;
        child_count = 1;
        subset[0] = new_node;
        fix_excess(0);
    }
}

template <typename T>
void BplusTree<T>::loose_insert(const T& entry){
    /*
           int i = first_ge(data, data_count, entry);
           bool found = (i<data_count && data[i] == entry);

           three cases:
             a. found: deal with duplicates
             ! found:
             b. leaf : insert entry in data at position i
             c. !leaf: subset[i]->loose_insert(entry)
                       fix_excess(i) if there is a need
                |   found     |   !found        |
          ------|-------------|-----------------|-------
          leaf  |  a. Deal    | b: insert entry |
                |     with    |    at data[i]   |
          ------|  duplicates |-----------------|-------
                |-------------| d: subset[i]->  |
          !leaf |subset[i+1]->|    loose_insert |
                |fix_excess(i)|    fix_excess(i)|
          ------|-------------|-----------------|-------

    */
    int i = first_ge(data, data_count, entry);  //how can I do this?zhenhanwoma
 //   cout << "check " << i << endl;
    bool found = ( i < data_count && data[i] == entry);
 //   cout << "max: " << MAXIMUM << endl;
    if (found){
        if ( is_leaf() ){
            data[i] = entry; //relace it
           // cout << "Sir. This is a duplicate entry: " << entry << endl;
        }
        else {

            //Add a possibility for BplusTree
            subset[i+1]->loose_insert(entry);
            if ( subset[i+1]->data_count > MAXIMUM ){
                //if my parent is tool large
                //end up with one excess entry in the root of our subset
               // data_count--;
                fix_excess(i+1);
            }
        }
    }
    else {
        if ( is_leaf() ){
       //     cout << "yes sir " <<entry<< endl;
            insert_item(data,i,data_count,entry);
          //  ordered_insert(data,data_count,entry);  //I did change data_count
   //         cout << "jjjj " << data_count << endl;
        }
        else {
            subset[i]->loose_insert(entry);
            //cout << "come back? " << endl;
            if ( subset[i]->data_count > MAXIMUM ){
                //if my parent is tool large
                //end up with one excess entry in the root of our subset
               // data_count--;
                fix_excess(i);
            }
        }
    }
}

template <typename T>
void BplusTree<T>::fix_excess(int i){
  //this node's child i has one too many items: 3 steps:
  //1. add a new subset at location i+1 of this node
  //2. split subset[i] (both the subset array and the data array) and move half
    //into
  // subset[i+1] (this is the subset we created in step 1.)
  //3. detach the last data item of subset[i] and bring it and insert it into
    //this node's data[]
  // //Note that this last step may cause this node to have too many items.
    //This is OK. This will be
  // dealt with at the higher recursive level. (my parent will fix it!)

    BplusTree<T>* excess_child = subset[i];
    //I declare an object or make subset[i] an object
   // cout << "hhh: " << excess_child->data_count << endl;
    assert(excess_child->data_count == MAXIMUM + 1);
    //we fix it because it reaches 3
    BplusTree<T>* new_child = new BplusTree<T>();
    //a new object ready to accept stuff
    insert_item(subset,i+1,child_count,new_child);  //insert an object
                                                   //or make it an object
    split(excess_child->data, excess_child->data_count, subset[i+1]->data,
            subset[i+1]->data_count);
    //if the suset[i] is not a leaf , I don't need to do this, do I?
    split(excess_child->subset, excess_child->child_count,subset[i+1]->subset,
            subset[i+1]->child_count);

    T item = T();
    detach_item(excess_child->data,excess_child->data_count,item);
    insert_item(data,i,data_count,item);
//excess_child->
    if ( excess_child->is_leaf() ){
        //insert the middle value to posi 0 of i+1, connect the links
        insert_item(subset[i+1]->data,0,subset[i+1]->data_count,item);
        if ( subset[i]->_next == nullptr ){  //this is when we insert 3rd entry
            subset[i+1]->_next = nullptr;
            subset[i]->_next = subset[i+1];
        }
        else { //we insert an emtry between two bpluetree
            BplusTree<T>* child_after = subset[i]->_next;
            subset[i+1]->_next = child_after;
            subset[i]->_next = subset[i+1];
        }
    }
}

//------------------------------------------------
//          R E M O V E
//------------------------------------------------

template <typename T>
void BplusTree<T>::remove(const T& entry){       //remove entry from the tree
    /*
    * ---------------------------------------------------------------------------------
    * Same as BTree:
    * Loose_remove the entry from this tree.
    * Shrink if you have to
    * ---------------------------------------------------------------------------------
    * once you return from loose_remove, the root (this object) may have no data and
    * only a single subset:
    * now, the tree must shrink:
    *
    * point a temporary pointer (shrink_ptr) and point it to this root's only subset
    * copy all the data and subsets of this subset into the root (through shrink_ptr)
    * now, the root contains all the data and poiners of it's old child.
    * now, simply delete shrink_ptr, and the tree has shrunk by one level.
    * Note, the root node of the tree will always be the same, it's the
    * child node we delete
    *
    *
    */
    loose_remove(entry);
    //cout << "uuuuuuuuuuu: " << data_count << endl;
    if ( (data_count == 0) && (child_count == 1) ){   //shrink the tree
   //     cout << "Did I come to shrink tree?" << endl;
        BplusTree<T>* shrink_ptr = subset[0]; //this root's only subset

        copy_array(data,shrink_ptr->data,data_count,shrink_ptr->data_count);
        copy_array(subset,shrink_ptr->subset,
                   child_count,shrink_ptr->child_count);

        shrink_ptr->data_count = 0;
        shrink_ptr->child_count = 0;
        delete shrink_ptr;
        //data = shrink_ptr;
    }
}


template <typename T>
void BplusTree<T>::loose_remove(const T& entry){
//allows MINIMUM-1 data elements in the root
    /* four cases:
               leaves:
                    a. not found: there is nothing to do
                    b. found    : just remove the target
               non leaf:
                    c. not found: subset[i]->loose_remove, fix_shortage(i)
                    d. found    : subset[i+1]->loose_remove, fix_shortage(i+1) [...]
                        (No More remove_biggest)

                 |   !found               |   found                 |
           ------|------------------------|-------------------------|-------
           leaf  |  a: nothing            | b: delete               |
                 |     to do              |    target               |
           ------|------------------------|-------------------------|-------
           !leaf | c:                     | d: B_PLUS_TREE          |
                 |  [i]->  loose_remove   |   [i+1]-> loose_remove  |
                 |  fix_shortage(i)       | fix_shortage(i+1) [...] |
           ------|------------------------|-------------------------|-------


         */
    int i = first_ge(data, data_count, entry);
    bool found = ( i < data_count && data[i] == entry);

    if ( is_leaf() ){
        if ( found ){
            T item = T();

      //      cout << "Did I delete item?" << endl;

            delete_item(data,i,data_count,item);
            if ( !(item == entry) ){
                cout << "God! You deleted a wrong entry!!!!!!" <<endl;
            }
        }
     //   cout << "I come here------?" <<endl;
        //there is nothing to do if not found
    }
    else { //not leaf
        //not leaf:
// ---- 000 B_PLUS_TREE: no more remove_biggest
        if ( found ){ //replace with the biggest item in subset and fix
                      //shortage if necessary
      //      cout << "I go to subset[i+1]?" <<endl;
            subset[i+1]->loose_remove(entry); //Important!!!!!!!!
            assert(i < child_count - 1);

            if (subset[i+1]->data_count < MINIMUM){ //Important!!!!!!!!
                //subset[i]->data_count is MINMUM - 1 now
                fix_shortage(i+1);
            }


//                if ( data_count < MINIMUM ){
                    int i = first_ge(data,data_count,entry);
                    bool found = ( i < data_count && data[i] == entry );
                    if ( found ){ //I found that in data
     //                   cout  << "I found : " << data[i] << " Original: " << entry << endl;
//                        assert ( 1 == 0);
                        subset[i+1]->get_smallest(data[i]);
                    }
                    else { //I went to subset[i+1] and found it
//                        int j = first_ge(subset[i]->data,subset[i]->data_count,entry);
//                        cout  << "I found : " << subset[i]->data[j] << " Original: " << entry << endl;
////                        assert ( 1 == 0);
//                        subset[i]->get_smallest(subset[i]->data[j]);

                        subset[i]->loose_remove(entry);
                    }
        }
        else { //din't find the target
     //       cout << "Did I find m subset?" <<endl;
      //      print_array(subset[i]->data,subset[i]->data_count,0);
            subset[i]->loose_remove(entry);
         //   cout << "Came bak from subset->loose_remove" <<endl;
           // print_array(subset[i+1]->data,subset[i+1]->data_count,0);
            if ( subset[i]->data_count < MINIMUM ){
         //       print_array(data,data_count,0);
                //subset[i]->data_count is MINMUM - 1 now
                fix_shortage(i);
            }
        }
    }
}

template <typename T>
void BplusTree<T>::get_smallest(T& entry){
    //replace entry with the left_most leaf of this tree
    // Keep looking in the first subtree (recursive)
    //  until you get to a leaf.
    // Then, replace entry with data[0] of the leaf node

 //   cout << "I get to get_smallest function" << endl;

    if ( is_leaf() ){   //or we keep looking in the last subset
        entry = data[0];
        //I don't do anything, but only record my entry with data[0]
    }
    else {
        subset[0]->get_smallest(entry);
    }
}

template <typename T>
BplusTree<T> *BplusTree<T>::fix_shortage(int i){
 //   cout << "Did I come here? Fix shortage" << endl;
 //   cout << i << " " << child_count << endl;
   // cout << subset[i+1]->data_count << endl;
   // cout << subset[i-1]->data_count << endl;
   // cout << child_count - 1 << endl;
//fix shortage of data elements in child i
    /*
         * fix shortage in subtree i:
         * if child i+1 has more than MINIMUM,
         *          (borrow from right) transfer / rotate left(i+1)
         * elif child i-1 has more than MINIMUM,
         *          (borrow from left) transfer /rotate right(i-1)
         * elif there is a left sibling,
         *          merge with prev child: merge(i-1)
         * else
         *          merge with next (right) child: merge(i)
         *
         *
         * returns a pointer to the fixed_subset
         */
  //  cout << "yes?" <<endl;
    if ( i == 0 ){
      //  print_array(data,data_count,0);
        if ( subset[i+1]->data_count > MINIMUM ){
    //        cout << "111111111Did I rotate left?" <<endl;
            //rotate left
            transfer_left(i+1);
        //    cout << "come back from rotate left" <<endl;
        }
        else {  //if ( child_count - 1 > i )
    //        cout << "Did I merge with next? " << endl;
            //there is a right child, merge child i with next child
            merge_with_next_subset(i);
        }
    }
    else {
     //   print_array(data,data_count,0);

        if ( i+1<child_count ){
 //this tells me that I can go ahead check my first if statement rotate left)
       //     cout << "yyyyyyyy"<< endl;
            if ( subset[i+1]->data_count > MINIMUM ){
   //             cout << "Did I rotate left?" <<endl;
                //rotate left
                transfer_left(i+1);
            }
            else if ( subset[i-1]->data_count > MINIMUM ){
   //             cout << "Did I rotate right?" << endl;
                //rotate right
                transfer_right(i-1);
            }
            else{  //
    //            cout << "Did I merge with prev? " << endl;

                //there is a right child, merge child i with next child
                merge_with_next_subset(i-1);
       //         cout << 11111 << endl;
       //         cout << data_count << endl;
             //   print_array(subset[i]->data,subset[i]->data_count,0);
            }
        }
        else if ( subset[i-1]->data_count > MINIMUM ){
  //          cout << "Did I rotate right?" << endl;
            //rotate right
            transfer_right(i-1);
        }
        else { //merge child i with left child
  //          cout << "Did I merge with prev?" << endl;
          //  merge_with_previous_subset(i);
            merge_with_next_subset(i-1);
        }

    }
    return subset[i];
}

template <typename T>
BplusTree<T> *BplusTree<T>::merge_with_next_subset(int i){
   // cout << "Come here first---" << endl;
//merge subset i with subset i+1
    /*
         * ----------------------------------------------------------------------
         *  Merge subset[i] with subset [i+1] REMOVE data[i];
         *  non leaf: same as BTree
         *  leaves  : delete but do not bring down data[i]
         * ----------------------------------------------------------------------
         *
         *   1. remove data[i] from this object
         *   2. if not a leaf, append it to child[i]->data:
         *   3. Move all data items from subset[i+1]->data to right of subset[i]->data
         *   4. Move all subset pointers from subset[i+1]->subset to
         *          right of subset[i]->subset
         *   5. delete subset[i+1] (store in a temp ptr)
         *   6. if a leaf, point subset[i]->next to temp_ptr->next
         *   6. delete temp ptr
         *
         *
         * non-leaf nodes: (same as BTree)
         * ------------------
         *  i = 0:
         *             [50  100]
         *          /      |     \
         *  [  ]         [75]       ....
         *    |         /    \
         *   [a]      [b]    [c]
         *
         *  bring down data[i], merge it with subset[i] and subset[i+1]:
         *      then, get rid of subset[i+1]
         *             [100]
         *               |
         *            [50|75]       ....
         *            /  |  \
         *         [a]  [b]  [c]
         *
         *
         *
         * leaf node:
         * ----------------
         * Exactly the same, but do not attach the deleted data[i] to subset[i]->data[ ]
         *
         *  i = 0 : merge 5 and [()]
         *        [7 | 10]
         *      /    |     \
         *  [5]->   [()]->  [10]
         *
         *  Delete data[i] (7), merge subset[i] and subset[i+1]
         *      WITHOUT bringing down data[i]
         *
         *        [10]
         *      /      \
         *  [5]->      [10]
         *
         *
         * i = 1 merge 7 and [()]
         *        [7 | 10]
         *      /    |     \
         *  [5]->   [7]->  [()]
         *
         *  Delete data[i] (10), merge subset[i] and subset[i+1]
         *      WITHOUT bringing down data[i]
         *
         *        [7]
         *      /     \
         *  [5]->      [7]
         *
         *
         *
         *
         */
    T item =T();
    delete_item(data,i,data_count,item);
    if ( !subset[i]->is_leaf() ){
        insert_item(subset[i]->data,subset[i]->data_count,
                    subset[i]->data_count,item);
    }

   // cout << "data's item: " << item << endl;

    merge(subset[i]->data,subset[i]->data_count,
          subset[i+1]->data,subset[i+1]->data_count);
    merge(subset[i]->subset,subset[i]->child_count,
          subset[i+1]->subset,subset[i+1]->child_count);
  //  print_array(subset[i]->data,subset[i]->data_count,0);
   // print_array(subset[i+1]->data,subset[i+1]->data_count,0); //empty now

    //link the nodes together: //Good
    if ( subset[i]->is_leaf() ){
        BplusTree<T>* temp = subset[i+1]->_next;
        subset[i]->_next = temp;
    }

    //delete_item(subset->data,i+1,subset->child_count,T());
    BplusTree<T>* temp_ptr = subset[i+1];
    delete temp_ptr;
    shift_left(subset,i+1,child_count);
   // cout << child_count << endl;
   // cout << data_count << endl;
 //   print_array(subset[i]->data,subset[i]->data_count,0);
   // cout << "end of merge with next" << endl;  //might be correct
    return subset[i];
}

template <typename T>
void BplusTree<T>::transfer_left(int i){   //transfer one element LEFT from child i
    /*
     * (0 < i < child_count) and (subset[i]->data_count > MINIMUM)
     * subset[i-1] has only MINIMUM - 1 entries.
     *
     * item transfers from child[i] to child [i-1]
     *
     * FIRST item of subset[i]->data moves up to data to replace data[i-1],
     * data[i-1] moves down to the RIGHT of subset[i-1]->data
     *
     *  i = 1:
     *              [50 100]
     *  [  ]        [65 75]       ....
     *            [a]  [b]  [c]
     *
     *  65 move up to replace 50 (data[i])   (it should be data[i-1] I think
     *  65's child (its child 0) moves over to be the child of 50
     *  50 moves down to the right of subset[i]->data
     *
     *              [65 100]
     *  [50]         [ 75 ]       ....
     *     [a]      [b]  [c]
     *
     *
     *
     *
     */

    // If necessary, shift first subset of subset[i] to end of subset[i-1]
  //  i++;  //i becomes 1 now

    if ( (0 < i < child_count) && (subset[i]->data_count > MINIMUM) ){
        BplusTree<T>* reguler_child = subset[i];
       // cout << reguler_child->data_count << endl;
        assert(reguler_child->data_count > MINIMUM);
        BplusTree<T>* short_child = subset[i-1];
       // cout << short_child->data_count << endl;
        assert(short_child->data_count == MINIMUM - 1);
        //shift over the existing entries to make room (I did it in insert_item
      //  shift_right(short_child->data,0,short_child->data_count);
        T item = T();
        delete_item(data,i-1,data_count,item);
        if ( !reguler_child->is_leaf() ){
            insert_item(short_child->data,short_child->data_count,
                        short_child->data_count,item);
        }

        T first_item_in_regulaer_child = T();
        delete_item(reguler_child->data,0,reguler_child->data_count,
                    first_item_in_regulaer_child);
       // cout << "llll" << first_item_in_regulaer_child << endl;
        if ( reguler_child->is_leaf() ){
            insert_item(short_child->data,short_child->data_count,
                        short_child->data_count,first_item_in_regulaer_child);
            //Important to get the item in regular child and put it in data
            T item_in_regular_child = reguler_child->data[0];
            insert_item(data,i-1,data_count,item_in_regular_child);
        }
        else { //not leaf
            insert_item(data,i-1,data_count,first_item_in_regulaer_child);
        }
                  //maybe 0 here

        if ( !reguler_child->is_leaf() ){
            //I think that I'm detaching a BTree object from regular_child

            insert_item(short_child->subset,short_child->child_count,
                        short_child->child_count,reguler_child->subset[0]);
            shift_left(reguler_child->subset,0,reguler_child->child_count);
        }
    }
}

template <typename T>
void BplusTree<T>::transfer_right(int i){
//transfer one element RIGHT from child i
    /* (i < child_count - 1) and (subset[i]->data_count > MINIMUM)
     * subset[i+ 1] has only MINIMUM - 1 entries.
     *
     * item transfers from child[i] to child [i+1]
     *
     * LAST item of subset[i]->data moves up to data to replace data[i],
     * data[i] moves down to the LEFT of subset[i+1]->data
     *
     * i = 1
     *                     [50 100]
     *      [20 30]        [65 75]          [ ] //it was 100 before
     *  [..] [..] [..]   [a] [b] [c]        [..]
     *
     *  75 moves up to replace 100 (data[i])
  *  75's child (its last child) moves over to be the (child 0) child of 100
     *  100 moves down to subset[i]->data
     *
     *                     [50 75]
     *      [20 30]          [65]          [75]
     *  [..] [..] [..]     [a] [b]        [c] [..]
     *
     *
     *
     *
     *
     */
    // If necessary, shift last subset of subset[i] to front of subset[i+1]
  //  i--;
    if ( (i < child_count - 1) && (subset[i]->data_count > MINIMUM) ){
        BplusTree<T>* reguler_child = subset[i];
        assert(reguler_child->data_count > MINIMUM);
        BplusTree<T>* short_child = subset[i+1];
        assert(short_child->data_count == MINIMUM - 1);
        //shift over the existing entries to make room (I did it in insert_item
      //  shift_right(short_child->data,0,short_child->data_count);

        T item = T();
        delete_item(data,i,data_count,item);
        if ( !reguler_child->is_leaf() )
        {
            insert_item(short_child->data,0,short_child->data_count,item);
        }

        T last_item_in_regulaer_child = T();
        detach_item(reguler_child->data,reguler_child->data_count,
                    last_item_in_regulaer_child);
      //  cout << last_item_in_regulaer_child << endl;
        if ( reguler_child->is_leaf() ){
            insert_item(short_child->data,0,short_child->data_count,last_item_in_regulaer_child);
        }
        insert_item(data,i,data_count,last_item_in_regulaer_child);

        if ( !reguler_child->is_leaf() ){ //I keep this for breadcrum
            //I think that I'm detaching a BTree object from regular_child

            insert_item(short_child->subset,0,short_child->child_count,
                        reguler_child->subset[reguler_child->child_count-1]);
            shift_left(reguler_child->subset,reguler_child->child_count-1,
                       reguler_child->child_count);
        }
    }
}


//---------------------------------------------------------------------
//            C O N T A I N S / F I N D / G E T / E T C .
//---------------------------------------------------------------------

template <typename T>
T* BplusTree<T>::find_ptr(const T& entry){
    //return a pointer to this key. NULL if not there.
    int i = first_ge(data,data_count,entry);
    bool found = (i < data_count && data[i] == entry);
    if ( found ){
        if ( is_leaf() ){
            return &data[i];
        }
        else {
            return subset[i+1]->find_ptr(entry);
        }
    }
    else {
        if ( is_leaf() ) {
            return nullptr;
        }
        else{
            //I will return the answer from here
            return subset[i]->find_ptr(entry);
        }
    }
}

template <typename T>
bool BplusTree<T> :: contains(const T& entry)
{
    int i = first_ge(data, data_count, entry);
    bool found = (i < data_count && data[i] == entry);
    if (is_leaf())
    {
        if ( found )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        if( found )
        {
            return subset[i+1]->contains(entry);
        }
        else
        {
            return subset[i]->contains(entry);
        }
    }
}

template <typename T>
T& BplusTree<T> :: get_existing(const T& entry)
{
//    T *item = find_ptr(entry); //find reurns a pointer
//    assert(*item == entry); //reference it to get real number
//    return *item; //return the address of entry

 //   assert(contains(entry)); //It doesn't need to be contained all the time
    const bool debug = false;
    int i = first_ge(data, data_count, entry);
    bool found = (i<data_count && data[i] == entry);
    if (is_leaf())
    {
        if (found)
        {
            return data[i];
        }
        else {
            if (debug) {
    //   cout<<"get_existing was called with nonexistent entry"<<endl;
            }
            assert(found);
        }
    }
    if (found) //inner node
    {
        return subset[i+1]->get(entry);
    }
    //or just return true?
    else //not found yet...
    {
        return subset[i]->get(entry);
    }
}

template <typename T>
T& BplusTree<T> :: get(const T& entry){
    //return a reference to entry in the tree
     if (!contains(entry))
         insert(entry);

     //cout << "ppppp" << endl;
     return get_existing(entry); //return a pair in map class
}

template <typename T>
const T& BplusTree<T> :: get(const T& entry) const
{
    //return a pointer to this key. NULL if not there.
    int i = first_ge(data,data_count,entry);
    bool found = (data[i] == entry);

    if ( found ){
        return data[i];
    }
//    else if ( is_leaf() ) {
//        return nullptr;
//    }
    else{
        //I will return the answer from here
        return subset[i]->get(entry);
    }
}

//---------------------------------------------------------------
  //    Size/Empty:
//---------------------------------------------------------------

template <typename T>
bool BplusTree<T> :: empty() const         //true if the tree is empty
{
    if ( this->data_count == 0 ){
        return true;
    }
    return false;
}

template<typename T>
bool BplusTree<T> :: is_leaf() const
{
    if ( child_count == 0 ){
        return true;
    }
    return false;
}

template <typename T>
int BplusTree<T> :: size() const
//count the number of elements in the tree
{
    int sum = 0;
    sum += data_count;
    for ( int i = 0 ; i < child_count ; i++ ) {
        sum += subset[i]->size();
    }
    return sum;
}

template <typename T>
bool BplusTree<T> :: is_valid(bool is_root)
//By default, it 's true for the root
{
    bool result = true;
    //check to see whether I check the subsets
    //cout << "--------------" << endl;
    if ( !is_root ){
        //except for root, data_count >= MINIMUM;
        if ( !(data_count >= MINIMUM) ){
            cout << data_count << "data_count >= MINIMUM is wrong" << endl;
            print_array(data,data_count,0);
            return false;
        }
    }
    if ( !is_leaf() ){
        //except for leaves, child_count = data_count+1;
        if ( !(child_count = data_count+1) ){
            cout << "child_count = data_count+1 is wrong" << endl;
            return false;
        }
        //The thing is that we can only test subset when we are not leaves
        for ( int i = 0 ; i < data_count ; i++ ) {
            if ( !is_gt(subset[i]->data,subset[i]->data_count,data[i]) ){
                cout << data[i] << endl;
                print_array(subset[i]->data,subset[i]->data_count,0);
                cout << "is always greater than is wrong" << endl;
                return false;
            }
        }
        for ( int i = 0 ; i < data_count ; i++ ) {
            if ( !is_le(subset[i+1]->data,subset[i+1]->data_count,data[i]) ){
                cout << "is always less than is wrong" << endl;
                return false;
            }
        }
        for ( int i = 0 ; i < child_count ; i++ ) {
            result = subset[i]->is_valid(false);

        }
    }
    //The following three we can test for anything
    if ( !(data_count <= MAXIMUM) ){
        cout << "data_count < MAXIMUM is wrong" << endl;
        return false;
    }
    if ( !(child_count <= MAXIMUM+1) ){
        cout << "child_count < MAXIMUM+1 is wrong" << endl;
        return false;
    }
    if (!is_ascending(data,data_count) ){
        cout << "is ascending is wrong" << endl;
        return false;
    }
    return result;
}


//---------------------------------------------------------------
  //    P R I N T  E T C.
//---------------------------------------------------------------
template <typename T>
void BplusTree<T>::print_tree(int level, ostream& outs) const{
    //1. print the last child (if any)
    if ( !this->is_leaf() ){
        subset[child_count-1]->print_tree(level+1,outs);
    }
    //2. print all the rest of the data and children
    for ( int i = data_count-1 ;i >= 0  ; i-- ) {
        outs << setw(4*level) << "" << "[" << data[i] << "]" << endl;
        if ( !is_leaf() ){
            subset[i]->print_tree(level+1,outs);
        }
    }
}

//---------------------------------------------------------------
  //    Test Functions:
//---------------------------------------------------------------

void test_insert();
void test_get_and_contains();
void test_is_valid();
void test_copy_and_clear();
void test_big_three();
void test_remove_poorman();
void test_remove_regular();
void test_remove_randomly();
void test_count_size();


//Random Test:
void test_BplusTree_auto(int tree_size=5000, int how_many=500, bool report=false);
bool test_BplusTree_auto(int how_many, bool report=true);
int Random(int lo, int hi);

#endif // BPLUSTREE_H
