#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H

/*
Features:

    -Not Implemented: None.

    -Implemented: This program at this point can manpluate insert, find,
    contain, get, get existing, copy, clear, iterator, and poormn's version of
    remove for BplusTree class. I tested my BTree's insertion and
    get, conatins, find, remove manually. And they all worked very well. Every
    time I insert or delete I test my b+tree with outputing the leaves using
    iterator, and it works very well.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
    After finishing this program, I had a better idea of what a BplusTree is,
    and I understand BplusTree better, especially the structure of BplusTree.
    Right now, my BplusTree can only do insert, conatins, get, find, copy,
    clear, remove but I have to do correct version of remove later since I only
    have a poorman's version of remove. I learned that I don't need to do
    remove with gibbest since whatever we have on breadcrums will appear on the
    leaves.
*/

#endif // Z_WORK_REPORT_H
