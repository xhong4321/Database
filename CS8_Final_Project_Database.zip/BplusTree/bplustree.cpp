#include "bplustree.h"

void test_insert()
{
    cout << "=================================================" << endl;
    cout << "Test Insert:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    cout << bt << endl;

    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;

    cout << "Test Copy Tree:" << endl;
    BplusTree<int> bpt;
    bpt.copy_tree(bt);
    cout << "The copied one:" << endl;
    cout << bpt << endl;
    cout << "riginal one:"  <<endl;
    cout << bt <<endl;

    cout << "Test Copied one with Iterator:" << endl;
    for ( BplusTree<int> :: Iterator it_copy = bpt.begin() ;
          it_copy != bpt.end() ; it_copy++ ) {
        cout << *it_copy << " ";
    }
    cout << endl;

    if ( !bpt.is_valid() ){
        cout << "The BplusTree is invalid." << endl;
    }
    else {
        cout << "The BplusTree is valid." << endl;
    }


    cout << "Test Clear:" << endl;
    bt.clear_tree();
    cout << "After Clear Tree:" << endl;
    cout << bt << endl;
    cout << "Finished!" << endl;
}

void test_get_and_contains()
{
    cout << "=================================================" << endl;
    cout << "Test Get and Contain:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    cout << bt << endl;

    if ( bt.contains(7) ){
        cout << "Yes, contains 7" << endl;
    }
    else {
        cout << "No, doesn't contain 7" << endl;
    }



//    if ( bt.contains(10) ){
//        cout << "Yes, contains 10" << endl;
//    }
//    else {
//        cout << "No, doesn't contain 10" << endl;
//    }
//    if ( bt.contains(3) ){
//        cout << "Yes, contains 3" << endl;
//    }
//    else {
//        cout << "No, doesn't contain 3" << endl;
//    }
//    if ( bt.contains(100) ){
//        cout << "Yes, contains 100" << endl;
//    }
//    else {
//        cout << "No, doesn't contain 100" << endl;
//    }
//    if ( bt.contains(89) ){
//        cout << "Yes, contains 89" << endl;
//    }
//    else {
//        cout << "No, doesn't contain 89" << endl;
//    }

//    cout << "We should alwasy get the item because we insert the item if we "
//            "find out that the btree doesn't have that item." << endl;
//    int item1 = bt.get(5);
//    if ( item1 == 5 ){
//        cout << "Yes, we get 5!" << endl;
//    }
//    else {
//        cout << "No, we didn't get 5." << endl;
//    }

//    int item2 = bt.get(6);
//    if ( item2 == 6 ){
//        cout << "Yes, we get 6!" << endl;
//    }
//    else {
//        cout << "No, we didn't get 6." << endl;
//    }

//    int item3 = bt.get(100);
//    if ( item3 == 100 ){
//        cout << "Yes, we get 100!" << endl;
//    }
//    else {
//        cout << "No, we didn't get 100." << endl;
//    }

//    int item4 = bt.get(34);
//    if ( item4 == 34 ){
//        cout << "Yes, we get 34!" << endl;
//    }
//    else {
//        cout << "No, we didn't get 34." << endl;
//    }
//    cout << "Result: " << endl;
//    cout << bt << endl;
}

void test_copy_and_clear()
{
    cout << "=================================================" << endl;
    cout << "Test Copy and CLear:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(100);
    bt.insert(34);
    cout << bt << endl;
    cout << "Size: " << bt.size() << endl;
    cout << "Test Copy:" << endl;
    BplusTree<int> bt2;
    bt2.copy_tree(bt);
    cout << bt2 << endl;
    cout << "Size: " << bt2.size() << endl;

    cout << "Test Copied one with Iterator:" << endl;
    for ( BplusTree<int> :: Iterator it_copy = bt2.begin() ;
          it_copy != bt2.end() ; it_copy++ ) {
        cout << *it_copy << " ";
    }
    cout << endl;


    BplusTree<int> bt3;
    bt3.copy_tree(bt2);
    cout << bt3 << endl;
    cout << "Size: " << bt3.size() << endl;

    cout << "Test Copied one with Iterator:" << endl;
    for ( BplusTree<int> :: Iterator it_copy = bt3.begin() ;
          it_copy != bt3.end() ; it_copy++ ) {
        cout << *it_copy << " ";
    }
    cout << endl;


//    cout << "Test Clear:" << endl;
//    bt2.clear_tree();
//    cout << bt2 << endl;
}

void test_big_three()
{
    cout << "=================================================" << endl;
    cout << "Test Big Three:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(100);
    bt.insert(34);
    cout << bt << endl;
    cout << "Test Copy Constructor:" << endl;
    BplusTree<int> bt2(bt);
    cout << bt2 << endl;
    cout << "Test Assignment operator:" << endl;
    BplusTree<int> bt3;
    bt3 = bt2;
    cout << bt3 << endl;
}

void test_count_size()
{
    cout << "============================================" << endl;
    cout << "Test Size: " << endl;
    BplusTree<int> bt;
    BplusTree<int> bt1;
    bt1.insert(5);
    bt1.insert(4);
    bt1.insert(3);
    bt1.insert(2);
    bt1.insert(6);
    bt1.insert(7);
    bt1.insert(8);
    bt1.insert(1);
    bt1.insert(89);
    bt1.insert(17);
    bt1.insert(5);
    bt1.insert(100);
    bt1.insert(34);
    cout << bt1 << endl;
    cout << "BTree's size is: " << bt1.size() << endl << endl;
}

void test_remove_poorman()
{
    cout << "=================================================" << endl;
    cout << "Test Remove:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(9);
    cout << bt << endl;
    if ( !bt.is_valid() ){
        cout << "The BplusTree is invalid." << endl;
    }
    else {
        cout << "The BplusTree is valid." << endl;
    }
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    cout << "Start Testing my poorman's version Remove:" << endl << endl;
    cout << "Test Rotate Left:" << endl; //GOOD
    cout << "Delete 7:" << endl;
    bt.remove(7);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    cout << "Test Rotate Right: " << endl; //GOOD
    cout << "Delete 4:" << endl;
    bt.remove(4);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    cout << "Test Merge With Next(i-1):" <<endl; //GOOD
    cout << "Delete 3:" << endl;
    bt.remove(3);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    cout << "Test Merge With Next(i):" <<endl;
    cout << "Delete 8:" << endl;
    bt.remove(8);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    cout << "Test Deleting a Non-Existing Item:" <<endl;
    cout << "Delete 10:" <<endl;
    bt.remove(10);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    if ( !bt.is_valid() ){
        cout << "The BplusTree is invalid." << endl;
    }
    else {
        cout << "The BplusTree is valid." << endl;
    }
}

void test_remove_regular()
{
    cout << "=================================================" << endl;
    cout << "Test Remove Rgular:" << endl << endl;
    BplusTree<int> bt;
    bt.insert(5);
    bt.insert(4);
    bt.insert(3);
    bt.insert(2);
    bt.insert(6);
    bt.insert(7);
    bt.insert(8);
    bt.insert(1);
    bt.insert(89);
    bt.insert(17);
    bt.insert(5);
    bt.insert(9);
    cout << bt << endl;
    if ( !bt.is_valid() ){
        cout << "The BplusTree is invalid." << endl;
    }
    else {
        cout << "The BplusTree is valid." << endl;
    }
    bt.remove(7);
    bt.remove(4);
    bt.remove(3);
    bt.remove(8);
    cout << bt << endl;
    bt.remove(1);
    bt.remove(17);

    cout << "Delete 5:" <<endl;
    bt.remove(5);
    cout << bt << endl << endl;
    cout << "Test for Iterator: " << endl;
    for ( BplusTree<int> :: Iterator it = bt.begin() ; it != bt.end() ; it++ )
    {
        cout << *it << " ";
    }
    cout << endl;
    cout << "----------------------------------------------------" << endl;

    bt.remove(89);
    cout << bt << endl;
}

void test_remove_randomly()
{
    cout << "=================================================" << endl;
    cout << "Test Remove Rgular:" << endl << endl;
    BplusTree<int> bt;
    for ( int i = 0 ; i < 50 ; i++ ) {
        int item = rand()%50 + 1;
        cout << i << " time : insert " << item << endl;
        bt.insert(item);
    }
    cout << bt << endl;
    for ( int j = 0 ; j < 40 ; j++ ) {
        int item = rand()%40 + 1;
        cout << j << " time : remove " << item << endl;
        bt.remove(item);
        if ( !bt.is_valid() ){
            cout << "The BTree is invalid." << endl;
            break;
            // cout << bt << endl;
        }
        else {
            cout << "YES!!!The BTree is valid." << endl;
        }
        cout << bt << endl;
    }

}

//1000           //100
void test_BplusTree_auto(int tree_size, int how_many, bool report)
{
    bool verified = true;
    for (int i = 0; i< how_many; i++){

        if (report){
            cout<<"*********************************************************"<<endl;
            cout<<" T E S T:    "<<i<<endl;
            cout<<"*********************************************************"<<endl;
        }


        if (!test_BplusTree_auto(tree_size, report)){
            cout<<"T E S T :   ["<<i<<"]    F A I L E D ! ! !"<<endl;
            verified = false;
            return;
        }
    }

    cout<<"**************************************************************************"<<endl;
    cout<<"**************************************************************************"<<endl;
    cout<<"             E N D     T E S T: "<<how_many<<" tests of "<<tree_size<<" items: ";
    cout<<(verified?"VERIFIED": "VERIFICATION FAILED")<<endl;
    cout<<"**************************************************************************"<<endl;
    cout<<"**************************************************************************"<<endl;
}
   //1000
bool test_BplusTree_auto(int how_many, bool report)
{
    const int MAX = 10000;
    assert(how_many < MAX);
    BplusTree<int> bt;
    int a[MAX];
    int original[MAX];
    int deleted_list[MAX];

    int original_size;
    int size;
    int deleted_size = 0;

//fill a[ ] (0,1,2,3,4,5,6,...,999)

    for (int i= 0; i< how_many; i++){
        a[i] = i;
    }

//shuffle a[ ]: Put this in a function!

    for (int i = 0; i< how_many; i++){
        int from = Random(0, how_many-1); //a random number 0-999
        int to = Random(0, how_many -1); //a random number 0-999
        int temp = a[to];
        a[to] = a[from];
        a[from] = temp;
    }

//copy  a[ ] -> original[ ]:
    copy_array(original, a, how_many, how_many);
    size = how_many;
    original_size = how_many;
    for (int i=0; i<size; i++){
        bt.insert(a[i]);
    }


    if (report){
        cout<<"========================================================"<<endl;
        cout<<"  "<<endl;
        cout<<"========================================================"<<endl;
        cout<<bt<<endl<<endl;
    }


    for (int i= 0; i<how_many; i++){
        int r = Random(0, how_many - i - 1);
        //  cout << r <<endl;
        //  cout << i << " times !!!!!!!!" <<endl;
        if (report){
            cout<<"========================================================"<<endl;
            cout<<bt<<endl;
            cout<<". . . . . . . . . . . . . . . . . . . . . . . . . . . . "<<endl;
            cout<<"deleted: "; print_array(deleted_list, deleted_size);
            cout<<"   from: "; print_array(original, original_size);
            cout<<endl;
            cout<<"  REMOVING ["<<a[r]<<"]"<<endl;
            cout<<"========================================================"<<endl;
        }
        bt.remove(a[r]);

//   cout << 111111111 << endl;

        delete_item(a, r, size, deleted_list[deleted_size++]);
//   cout << 222 << endl;

        if (!bt.is_valid()){
            cout<<setw(6)<<i<<" I N V A L I D   T R E E"<<endl;
            cout<<"Original Array: "; print_array(original, original_size);
            cout<<"Deleted Items : "; print_array(deleted_list, deleted_size);
            cout<<endl<<endl<<bt<<endl<<endl;
            return false;
        }
    }

    if (report) cout<<" V A L I D    T R E E"<<endl;

    return true;
}

int Random(int lo, int hi)
{
    int r = rand()%(hi-lo+1)+lo;

    return r;
}
