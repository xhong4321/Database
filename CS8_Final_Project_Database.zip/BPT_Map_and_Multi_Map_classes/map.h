#ifndef MAP_H
#define MAP_H

#include <iostream>
#include "pair.h"
//#include "../BTree_class/btree.h"
#include "../BplusTree/bplustree.h"
using namespace std;

template <typename K,typename V>
class Map{
public:
    typedef BplusTree<Pair<K, V> > map_base;
    class Iterator{
    public:
        friend class Map;
        Iterator(typename map_base::Iterator it)
        {
            _it = it;
        }
        Iterator operator ++(int)
        {
            return _it++;
        }

        Iterator operator ++()
        {
            return ++_it;
        }

        Pair<K, V> operator *()
        {
            return *(_it);
        }

        friend bool operator ==(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._it == rhs._it ){
                return true;
            }
            return false;
        }

        friend bool operator !=(const Iterator& lhs, const Iterator& rhs)
        {
            if ( lhs._it != rhs._it ){
                return true;
            }
            return false;
        }

    private:
        typename map_base::Iterator _it;
    };

    Map();

    Iterator begin();
    Iterator end();
    int size() const;

    void insert(const K& k, const V& v);
    void remove(const K& key);
    bool empty() const;
    bool contains(const K& target);
    void clear();
    const V& operator[](const K& key) const;
    V& operator[](const K& key);
    V get(const K& key);



    friend ostream& operator<<(ostream& outs, const Map<K, V>& print_me){
        outs << print_me._map << endl;
        return outs;
    }

private:
    BplusTree<Pair<K,V>> _map;
};

//=================================================================
//                Definitions:
//=================================================================

template <typename K, typename V>
Map<K,V> :: Map()
{
    //blank
}

template <typename K, typename V>
void Map<K,V> :: remove(const K& key)
{
    _map.remove(key);
}

template <typename K, typename V>
bool Map<K,V> :: empty() const
{
    return _map.empty();
}

template <typename K, typename V>
bool Map<K,V> :: contains(const K& target)
{
    return _map.contains(Pair<K,V>(target,V()));
}

template <typename K, typename V>
void Map<K,V> :: clear()
{
    _map.clear_tree();
}

template <typename K,typename V>
const V& Map<K,V> :: operator[](const K& key) const
{
   // Pair<K,V> pair = _map.get(Pair<K,V>(key,V()));
    return _map.get(Pair<K,V>(key,V())).value;
}

template <typename K,typename V> //direct access to the pair.value
V& Map<K,V> :: operator[](const K& key) //ability to read and write in the list
{
  //  Pair<K,V> pair = _map.get(Pair<K,V>(key,V())); //return a Pair<K,V>
    //here, making a copy

   // return pair.value;

    return _map.get(Pair<K,V>(key,V())).value;
    //return a reference to the local scope
}

template<typename K, typename V>
V Map<K,V> :: get(const K& key)
{
    return _map.get(Pair<K,V>(key,V())).value;
}


template <typename K,typename V>
typename Map<K,V> :: Iterator Map<K,V> :: begin ()
{
    return Iterator(_map.begin());
}

template <typename K,typename V>
typename Map<K,V> :: Iterator Map<K,V> :: end ()
{
    return Iterator(_map.end());
}

template <typename K, typename V>
int Map<K,V> :: size() const
{
    return _map.size();
}


//=================================================================
//                Test Functions:
//=================================================================

void test_reading_and_writing_map_btree();
void test_reading_and_writing_map_bpt();
void test_map_find_contains();
void test_map_remove();

void test_for_table();

template <typename K,typename V>
//for checking the const version subscript operator
void test_const(const Map<K,V>& m, const string& s)
{
    if ( !m.empty() ){
        cout << s << ": " << m[s] << endl;
    }
}

#endif // MAP_H
