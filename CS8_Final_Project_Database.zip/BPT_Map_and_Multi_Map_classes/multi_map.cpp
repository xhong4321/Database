#include "multi_map.h"

//void test_reading_and_writing_mmap_btree()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BTree:" << endl;
//    MMap<string,string> majors;
//    majors["Jerry"] += "Mechanical Engineering";
//    majors["Jerry"] += "Aerospace Engineering";
//    majors["Link"] += "Computer Science";
//    majors["Kevin"] += "Computer Science";
//    majors["Nathan"] += "Math";
//    majors["Tony"] += "civil Engineering";
//    majors["Joanna"] += "Nursing";
//    majors["Sheron"] += "Psychology";
//    cout << "Test non-const get:" << endl << endl;
//    cout << majors << endl;

//    cout << "Test const get:" << endl << endl;
//    test_const_mmap(majors,"Jerry");
//}

//void test_reading_and_writing_mmap_bpt()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BplusTree:" << endl;
//    MMap<string,string> majors;
//    majors["Jerry"] += "Mechanical Engineering";
//    majors["Jerry"] += "Aerospace Engineering";
//    majors["Link"] += "Computer Science";
//    majors["Kevin"] += "Computer Science";
//    majors["Nathan"] += "Math";
//    majors["Tony"] += "civil Engineering";
//    majors["Joanna"] += "Nursing";
//    majors["Sheron"] += "Psychology";
//    cout << "Test non-const get:" << endl << endl;
//    cout << majors << endl;

//    cout << "Test const get: Jerry" << endl << endl;
//    test_const_mmap(majors,"Jerry");
//    cout << endl;

//    cout << "Test for Iterator:" << endl;
//    for ( MMap<string,string> :: Iterator it = majors.begin() ;
//          it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;

//}

//void test_mmap_find_contains()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BplusTree:" << endl;
//    MMap<string,string> majors;
//    majors["Jerry"] += "Mechanical Engineering";
//    majors["Jerry"] += "Aerospace Engineering";
//    majors["Link"] += "Computer Science";
//    majors["Kevin"] += "Computer Science";
//    majors["Nathan"] += "Math";
//    majors["Tony"] += "civil Engineering";
//    majors["Joanna"] += "Nursing";
//    majors["Sheron"] += "Psychology";
//    cout << "Origianl BplusTree:" << endl << endl;
//    cout << majors << endl<<endl;
//    cout << "-------------------------------------" << endl;
//    cout << "Test Conatins: " << endl<< endl;
//    if ( majors.contains("Joanna") ){
//        cout << "Yes, it contains Joanna!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Joanna!" << endl;
//    }
//    if ( majors.contains("Wong") ){
//        cout << "Yes, it contains Wong!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Wong!" << endl;
//    }
//    if ( majors.contains("Jerry") ){
//        cout << "Yes, it contains Jerry!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Jerry!" << endl;
//    }

//}

//void test_mmap_remove()
//{
//    cout << "=====================================" << endl;
//    cout << "Test Remove With BplusTree:" << endl;
//    MMap<string,string> majors;
//    majors["Jerry"] += "Mechanical Engineering";
//    majors["Jerry"] += "Aerospace Engineering";
//    majors["Link"] += "Computer Science";
//    majors["Kevin"] += "Computer Science";
//    majors["Nathan"] += "Math";
//    majors["Tony"] += "civil Engineering";
//    majors["Joanna"] += "Nursing";
//    majors["Sheron"] += "Psychology";
//    cout << "Origianl BplusTree:" << endl << endl;
//    cout << majors << endl<<endl;
//    cout << "-------------------------------------" << endl;

//    cout << "Remove Link:" << endl;
//    majors.remove("Link");
//    cout << majors <<endl;
//    cout << "Test for Iterator:" << endl;
//    for ( MMap<string,string> :: Iterator it = majors.begin() ;
//          it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;
//    cout << "-------------------------------------" << endl;


//    cout << "Remove Jerry:" << endl;
//    majors.remove("Jerry");
//    cout << majors <<endl;
//    cout << "Test for Iterator:" << endl;
//    for ( MMap<string,string> :: Iterator it = majors.begin() ;
//          it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;
//    cout << "-------------------------------------" << endl;
//}

void test_for_crashing()
{
    cout << "=====================================" << endl;
    cout << "Test Remove With BplusTree:" << endl;
    MMap<int,string> test;
    int round = 200;
    for ( int i = 0 ; i < round ; i++ ) {
        int index = rand()%200 + 1;
        test[index] += "what'sUp";

    }
    cout << "Result: " << endl << endl;
    cout << test << endl;


    cout << "Remove:  " << endl;
    int time = 180;
    for ( int j = 0 ; j < time ; j++ ) {
        int index = rand()%200 + 1;
        cout << "[" << j << "] " << "Before remove: " << index << endl;
        if ( test.contains(index) ){
            cout << "The tree contains " << index << endl;
            cout << test << endl;
        }
        else {
            cout << "No, it doesn't contain " << index << endl;
        }
        test.remove(index);
        cout << "After remove: " << index << endl;
        if ( test.is_valid() ){
            cout << "This time, the tree is valid" << endl;
        }
        else {
            cout << "This is a invalid Tree!!!!!!!!" << endl;
        }
    }
    cout << "Result: " << endl << endl;
    cout << test << endl;
}

void test_mmap_lower_upper_bound()
{
//    cout << "=====================================" << endl;
//    MMap<string,long> mmap;
//    mmap["command"] += 10;
//    mmap["table"] += 20;
//    mmap["fields"] += 100;
//    mmap["values"] += 29;
//    mmap["comand"] += 40;
//    mmap["conditions"] += 50;
//    mmap["command"] += 10;
//    mmap["table"] += 20;
//    mmap["field_names"] += 100;
//    mmap["big"] += 29;
//    mmap["hello"] += 40;
//    mmap["conditions"] += 50;
//    cout << "Result: " << endl << endl;
//    cout << mmap << endl;

//    cout << "---------------------------------------------" << endl;
//    cout << "This is less than for select_simple_condition:" << endl; //good
//    for ( MMap<string,long> :: Iterator it = mmap.begin() ; it != mmap.lower_bound("fields") ; it++ )
//    {
//        cout << *it << endl;
//    }
//    co/*ut << "---------------------------------------------" << endl;

//    cout << "---------------------------------------------" << endl;
//    cout << "This is less than and equal to for select_simple_condition:" << endl; //good
//    MMap<string,long> :: Iterator test = mmap.begin();
//    while ( test != mmap.upper_bound("fields")  ) {
//        cout << *test << endl;
//        test++;
//    }
//    cout << *test << endl;

//    for ( MMap<string,long> :: Iterator it = mmap.begin() ; it != mmap.upper_bound("fields") ; it++ )
//    {
//        cout << *it << endl;
//    }
 //   cout << "---------------------------------------------" << endl;

//    cout << "---------------------------------------------" << endl;
//    cout << "This is greater than to for select_simple_condition:" << endl; //good
//    for ( MMap<string,long> :: Iterator it = mmap.upper_bound("fields") ; it != mmap.end() ; it++ )
//    {
//        cout << *it << endl;
//    }
//    cout << "---------------------------------------------" << endl;

//    cout << "---------------------------------------------" << endl;
//    cout << "This is greater than and equal to for select_simple_condition:" << endl; //good
//    for ( MMap<string,long> :: Iterator it = mmap.lower_bound("fields") ; it != mmap.end() ; it++ )
//    {
//        cout << *it << endl;
//    }
//    cout << "---------------------------------------------" << endl;
}











