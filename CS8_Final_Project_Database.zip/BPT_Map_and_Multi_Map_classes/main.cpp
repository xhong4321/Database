/*
 * Author: Xiangyu Hong
 * Project: BPT Map and Multi Map classes
 * Purpose: The purpose of this program is to create Map class and MMap class
 * which are based on our BTree class. We make sure to finish insert, get,
 * contains, find, subscript, and remove functions
 * Notes: I only used string to test the pogram
*/

#include <iostream>
#include "map.h"
#include "multi_map.h"

using namespace std;

int main()
{
    srand(time(0));
    cout << endl << endl << endl;

    //test_reading_and_writing_map_btree(); //GOOD
    //test_reading_and_writing_map_bpt(); //GOOD
    //test_map_find_contains(); //GOOD
    //test_map_remove(); //GOOD
    //test_reading_and_writing_mmap_btree(); //GOOD
    //test_reading_and_writing_mmap_bpt(); //GOOD
    //test_mmap_find_contains(); //GOOD
    //test_mmap_remove(); //GOOD

    //test_for_crashing();
    //test_for_table();


    test_mmap_lower_upper_bound();

    cout << endl << endl << "================End==============" << endl;
    return 0;
}
