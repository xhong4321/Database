#include "map.h"

//void test_reading_and_writing_map_btree()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BTree:" << endl;
//    Map<string,string> majors;
//    majors["Jerry"] = "Mechanical Engineering";
//    majors["Link"] = "Computer Science";
//    majors["Kevin"] = "Computer Science";
//    majors["Nathan"] = "Math";
//    majors["Tony"] = "civil Engineering";
//    majors["Joanna"] = "Nursing";
//    majors["Sheron"] = "Psychology";
//    cout << "Test non-const get:" << endl << endl;
//    cout << majors << endl;

//    cout << "Test const get:" << endl << endl;
//    test_const(majors,"Tony");
//}

//void test_reading_and_writing_map_bpt()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BplusTree:" << endl;
//    Map<string,string> majors;
//    majors["Jerry"] = "Mechanical Engineering";
//    majors["Link"] = "Computer Science";
//    majors["Kevin"] = "Computer Science";
//    majors["Nathan"] = "Math";
//    majors["Tony"] = "civil Engineering";
//    majors["Joanna"] = "Nursing";
//    majors["Sheron"] = "Psychology";
//    cout << "Test non-const get:" << endl << endl;
//    cout << majors << endl;

//    cout << "Size: " << majors.size() << endl;

//    cout << "Test const get: Tony" << endl << endl;
//    test_const(majors,"Tony");
//    cout << endl;

//    cout << "Test for Iterator:" << endl;
//    for ( Map<string,string> :: Iterator it = majors.begin() ; it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;
//}


//void test_map_find_contains()
//{
//    cout << "=====================================" << endl;
//    cout << "Test With BplusTree:" << endl;
//    Map<string,string> majors;
//    majors["Jerry"] = "Mechanical Engineering";
//    majors["Link"] = "Computer Science";
//    majors["Kevin"] = "Computer Science";
//    majors["Nathan"] = "Math";
//    majors["Tony"] = "civil Engineering";
//    majors["Joanna"] = "Nursing";
//    majors["Sheron"] = "Psychology";
//    cout << "Original BplueTree:" << endl << endl;
//    cout << majors << endl;
//    cout << "-------------------------------------" << endl;
//    cout << "Test Conatins: " << endl<< endl;
//    if ( majors.contains(Pair<string,string>("Joanna","Nursing")) ){
//        cout << "Yes, it contains Joanna!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Joanna!" << endl;
//    }
//    if ( majors.contains(Pair<string,string>("Wong","")) ){
//        cout << "Yes, it contains Wong!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Wong!" << endl;
//    }
//    if ( majors.contains(Pair<string,string>("Jerry","")) ){
//        cout << "Yes, it contains Jerry!" << endl;
//    }
//    else {
//        cout << "No, it doesn;t contain Jerry!" << endl;
//    }
//}

//void test_map_remove()
//{
//    cout << "=====================================" << endl;
//    cout << "Test Remove With BplusTree:" << endl;
//    Map<string,string> majors;
//    majors["Jerry"] = "Mechanical Engineering";
//    majors["Link"] = "Computer Science";
//    majors["Kevin"] = "Computer Science";
//    majors["Nathan"] = "Math";
//    majors["Tony"] = "civil Engineering";
//    majors["Joanna"] = "Nursing";
//    majors["Sheron"] = "Psychology";
//    cout << "Original BplueTree:" << endl << endl;
//    cout << majors << endl;
//    cout << "-------------------------------------" << endl;

//    cout << "Remove Link:" << endl;
//    majors.remove("Link");
//    cout << majors <<endl;
//    cout << "Test for Iterator:" << endl;
//    for ( Map<string,string> :: Iterator it = majors.begin() ;
//          it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;
//    cout << "-------------------------------------" << endl;


//    cout << "Remove Jerry:" << endl;
//    majors.remove("Jerry");
//    cout << majors <<endl;
//    cout << "Test for Iterator:" << endl;
//    for ( Map<string,string> :: Iterator it = majors.begin() ;
//          it != majors.end() ; it++ ) {
//        cout << *it << endl;
//    }
//    cout << endl;
//    cout << "-------------------------------------" << endl;
//}

void test_for_table()
{
    cout << "=====================================" << endl;
    cout << "Test Remove With BplusTree:" << endl;
    Map<int,string> test;
    int round = 50;
    for ( int i = 0 ; i < round ; i++ ) {
        int index = rand()%60 + 1;
        test[index] = "what'sUp";
    }

    cout << "Result: " << endl << endl;
    cout << test << endl;


    cout << "Remove:  " << endl;
    int time = 40;
    for ( int j = 0 ; j < time ; j++ ) {
        int index = rand()%40 + 1;
        cout << "[" << j << "] " << "Before remove: " << index << endl;
        if ( test.contains(index) ){
            cout << "The tree contains " << index << endl;
            cout << "answer: " << test[index] << endl;
            string item = test[index];
            cout << "item = "<< item << endl;
        }
        else {
            cout << "No, it doesn't contain " << index << endl;
        }

    }
    cout << "Result: " << endl << endl;
    cout << test << endl;



}



