#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H


/*
Features:

    -Not Implemented: None.

    -Implemented: Map and MMap class can do insert, remove, get, contain, find,
     and subscript operator, and those functions are all based on BplusTree
     class. The difference between a Map class and a MMap class is that MMap
     class can take in multiple information for one key whereas Map class can
     only take in one information for one key.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
    After finishing this program, I got to review my BplusTree class,
    especially my BplueTree's Iterator part. Since I haven't touched Iterator
    for a very long time, I was having trouble with implementing the code for
    deference operator and two increment operators. But my BplusTree's Iterator
    was good, so I was able to fix my MMap's Iterator. Actually, Map's Iterator
    and MMap's Iterator are the same. I think the only problem will be my
    correct version of removw. My Mpa and MMap will be perfect after I have a
    good version of remove in BplusTree class.
*/

#endif // Z_WORK_REPORT_H
