#ifndef OVERLOADING_VECTOR_FUNC_H
#define OVERLOADING_VECTOR_FUNC_H

#include <iostream>
#include <vector>
using namespace std;

//-------------- Vector Extra operators: ---------------------

template <typename T, typename U>
ostream& operator <<(ostream& outs, const vector<U>& list); //print vector list

template <typename T, typename U>
vector<T>& operator +=(vector<T>& list, const U& addme); //list.push_back addme



//---------------------------------------------------------------------------

template <typename T, typename U>
ostream& operator <<(ostream& outs, const vector<U>& list) //print vector list
{
  //  outs << "[";
    for (int i = 0; i < list.size(); ++i) {
        outs << list[i];
        if (i != list.size() - 1)
            outs << " , ";
    }
   // outs << "]" << endl;
    return outs;
}

//template <typename T> //This is for testing my MMap in my Parser
//ostream& operator <<(ostream& outs, const vector<T>& list) //print vector list
//{
//  //  outs << "[";
//    for (int i = 0; i < list.size(); ++i) {
//        outs << list[i];
//        if (i != list.size() - 1)
//            outs << " , ";
//    }
//   // outs << "]" << endl;
//    return outs;
//}

template <typename T, typename U>
vector<T>& operator +=(vector<T>& list, const U& addme) //list.push_back addme
{
    //this push_back is a void function, so we don't return list.push_back()
    list.push_back(addme);
    return list;
}


#endif // OVERLOADING_VECTOR_FUNC_H
