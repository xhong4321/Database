#ifndef Z_OUTPUT_MMAP_H
#define Z_OUTPUT_MMAP_H

/*
 *
 *
 *
 *
 * ALL RESULTS HAVE BEEN VERTIFIED
 *
 *
 *

=====================================
Test With BplusTree:
Test non-const get:

        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
    [Nathan : Math]
        [Link : Computer Science]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]
        [Jerry : Mechanical Engineering , Aerospace Engineering]


Test const get: Jerry

Jerry: Mechanical Engineering , Aerospace Engineering

Test for Iterator:
Jerry : Mechanical Engineering , Aerospace Engineering
Joanna : Nursing
Kevin : Computer Science
Link : Computer Science
Nathan : Math
Sheron : Psychology
Tony : civil Engineering



================End==============
Press <RETURN> to close this window...


=====================================
Test With BTree:
Test non-const get:

    [Tony : civil Engineering]
    [Sheron : Psychology]
[Nathan : Math]
    [Link : Computer Science]
[Kevin : Computer Science]
    [Joanna : Nursing]
    [Jerry : Mechanical Engineering , Aerospace Engineering]


Test const get:

Jerry: Mechanical Engineering , Aerospace Engineering


================End==============
Press <RETURN> to close this window...

----------------------------------------------------------------

=====================================
Test With BplusTree:
Test non-const get:

        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
    [Nathan : Math]
        [Link : Computer Science]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]
        [Jerry : Mechanical Engineering , Aerospace Engineering]


Test const get:

Jerry: Mechanical Engineering , Aerospace Engineering


================End==============
Press <RETURN> to close this window...

----------------------------------------------------------------

=====================================
Test With BplusTree:
Origianl BplusTree:

        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
    [Nathan : Math]
        [Link : Computer Science]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]
        [Jerry : Mechanical Engineering , Aerospace Engineering]



-------------------------------------
Test Conatins:

Yes, it contains Joanna!
No, it doesn;t contain Wong!
Yes, it contains Jerry!


================End==============
Press <RETURN> to close this window...

----------------------------------------------------------------

=====================================
Test Remove With BplusTree:
Origianl BplusTree:

        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
    [Nathan : Math]
        [Link : Computer Science]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]
        [Jerry : Mechanical Engineering , Aerospace Engineering]



-------------------------------------
Remove Link:
Did I merge with next?
        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]
        [Jerry : Mechanical Engineering , Aerospace Engineering]


Test for Iterator:
Jerry : Mechanical Engineering , Aerospace Engineering
Joanna : Nursing
Kevin : Computer Science
Nathan : Math
Sheron : Psychology
Tony : civil Engineering

-------------------------------------
Remove Jerry:
        [Tony : civil Engineering]
        [Sheron : Psychology]
    [Sheron : ]
        [Nathan : Math]
[Link : Computer Science]
        [Kevin : Computer Science]
    [Kevin : ]
        [Joanna : Nursing]


Test for Iterator:
Joanna : Nursing
Kevin : Computer Science
Nathan : Math
Sheron : Psychology
Tony : civil Engineering

-------------------------------------


================End==============
Press <RETURN> to close this window...


 *
 *
 *
 *
 */

#endif // Z_OUTPUT_MMAP_H
