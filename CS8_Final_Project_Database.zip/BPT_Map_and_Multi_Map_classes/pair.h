#ifndef PAIR_H
#define PAIR_H

#include<iostream>
using namespace std;

template <typename K, typename V>
struct Pair{
    K key;
    V value;

    Pair(const K& k=K(), const V& v=V())
    {
        key = k;
        value = v;
    }

    friend ostream& operator <<(ostream& outs, const Pair<K, V>& print_me)
    {
        outs << print_me.key << " : " << print_me.value;
        return outs;
    }

    friend bool operator ==(const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        if ( lhs.key == rhs.key ){
            return true;
        }
        return false;
    }



    friend bool operator < (const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        if ( lhs.key < rhs.key ){
            return true;
        }
        return false;
    }

    friend bool operator > (const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        if ( lhs.key > rhs.key ){
            return true;
        }
        return false;
    }

    friend bool operator <= (const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        if ( lhs.key <= rhs.key ){
            return true;
        }
        return false;
    }
    //I add this function, but I'm not sure whether I should do this or not
    friend bool operator >= (const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        if ( lhs.key >= rhs.key ){
            return true;
        }
        return false;
    }

    friend Pair<K, V> operator + (const Pair<K, V>& lhs, const Pair<K, V>& rhs)
    {
        return rhs; //I trust Professor Barkeshli!
    }
};

#endif // PAIR_H
